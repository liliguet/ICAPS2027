"""Fixed, pre-registered stratified subset for long (1800 s) runs: alpha in {1.0,...,1.5}, beta in {0.4,...,0.9},
seed 1 only (36 instances). The rule is fixed in advance and does not look at any result."""
import os, sys, shutil
src, out = sys.argv[1], sys.argv[2]; os.makedirs(out, exist_ok=True); c = 0
for a in ['1.00', '1.10', '1.20', '1.30', '1.40', '1.50']:
    for b in ['0.40', '0.50', '0.60', '0.70', '0.80', '0.90']:
        f = os.path.join(src, f'a{a}_b{b}_s1.txt')
        if os.path.exists(f): shutil.copy(f, out); c += 1
print(out, c)

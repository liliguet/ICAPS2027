"""Compare runs with reference optima (null = infeasible)."""
import json, sys
ref = json.load(open(sys.argv[2])); bad = 0; n = 0
for l in open(sys.argv[1]):
    r = json.loads(l); b = ref.get(r['instance'], 'missing')
    if b == 'missing': continue
    n += 1
    ok = r.get('ok') and ((b is None and r.get('infeasible')) or (b is not None and r.get('optimal') and r.get('cost') == b and r.get('valid') is not False))
    if not ok: bad += 1; print('MISMATCH', r['instance'], r['variant'], r.get('cost'), b)
print('runs', n, 'mismatches', bad)

"""Independent verification of a proof log written by `lu_rpid --dump-certs FILE`.
For every stored certificate (U, L_U) it recomputes L_U with a different algorithm (enumeration of all orders of U
for |U| <= 8, a memoised recursion over (first customer, remaining set) otherwise) on an independently computed
metric closure, checks that the certificate really refutes the state where it was learned, and checks every logged
prune event (U subset of the unvisited set and pi_x > L_x for all x in U).
usage: python3 verify_certs.py INSTANCE LOG   -> prints a one-line JSON summary"""
import sys, json, itertools
from functools import lru_cache
NEGINF = float('-inf')

def read(path):
    v = open(path).read().split(); n = int(v[0])
    D = [[int(round(float(v[1 + i * n + j]))) for j in range(n)] for i in range(n)]
    tw = [(int(round(float(v[1 + n * n + 2 * i]))), int(round(float(v[2 + n * n + 2 * i])))) for i in range(n)]
    return n, D, tw

def closure(n, D):
    F = [[0 if i == j else D[i][j] for j in range(n)] for i in range(n)]
    for k in range(n):
        for i in range(n):
            for j in range(n):
                if F[i][k] + F[k][j] < F[i][j]: F[i][j] = F[i][k] + F[k][j]
    return F

def latest_by_orders(U, F, tw):
    """max over orders starting at x of the latest feasible start at x (backward pass along the order)."""
    a = {x: tw[x][0] for x in U}; b = {x: tw[x][1] for x in U}; b0 = tw[0][1]
    best = {x: NEGINF for x in U}
    for perm in itertools.permutations(U):
        L = [0] * len(perm); k = len(perm) - 1
        L[k] = min(b[perm[k]], b0 - F[perm[k]][0])
        for i in range(k - 1, -1, -1): L[i] = min(b[perm[i]], L[i + 1] - F[perm[i]][perm[i + 1]])
        if all(a[perm[i]] <= L[i] for i in range(k + 1)): best[perm[0]] = max(best[perm[0]], L[0])
    return best

def latest_by_recursion(U, F, tw):
    b0 = tw[0][1]
    @lru_cache(maxsize=None)
    def lat(x, rest):                     # latest start at x, then serve frozenset rest, then depot
        if not rest: v = min(tw[x][1], b0 - F[x][0])
        else:
            nxt = max((lat(y, rest - {y}) - F[x][y] for y in rest), default=NEGINF)
            v = min(tw[x][1], nxt)
        return v if v >= tw[x][0] else NEGINF
    return {x: lat(x, frozenset(U) - {x}) for x in U}

def main(inst, log):
    n, D, tw = read(inst); F = closure(n, D)
    certs, events, meta = [], [], None
    for line in open(log):
        if line.startswith('C '):
            body = line[2:]; i1 = body.index(']') + 1; i2 = body.index(']', i1) + 1
            U = json.loads(body[:i1]); L = [float(x) if int(x) > -10 ** 17 else NEGINF for x in json.loads(body[i1:i2])]
            a, t = map(int, body[i2:].split()); certs.append((U, L, a, t))
        elif line.startswith('E '):
            p = line[2:].split(' ', 3); events.append((int(p[0]), int(p[1]), int(p[2]), json.loads(p[3])))
        elif line.startswith('N '): meta = list(map(int, line.split()[1:]))
    pi = lambda a, t, x: max(t + F[a][x], tw[x][0])
    bad_L = bad_learn = bad_event = 0; by_orders = 0
    for U, L, a, t in certs:
        if len(U) <= 8: ref = latest_by_orders(U, F, tw); by_orders += 1
        else: ref = latest_by_recursion(U, F, tw)
        if any(ref[x] != L[i] for i, x in enumerate(U)): bad_L += 1
        if not all(pi(a, t, x) > ref[x] for x in U): bad_learn += 1
    for uid, a, t, R in events:
        U, L, _, _ = certs[uid]; Rs = set(R)
        if not (set(U) <= Rs and all(pi(a, t, x) > L[i] for i, x in enumerate(U))): bad_event += 1
    print(json.dumps(dict(instance=inst.split('/')[-1], certs=len(certs), verified_by_orders=by_orders, events_checked=len(events),
                          events_total=meta[1] if meta else None, bad_L=bad_L, bad_learning_state=bad_learn, bad_events=bad_event,
                          ok=bad_L == 0 and bad_learn == 0 and bad_event == 0)))

if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])

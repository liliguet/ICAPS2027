#!/usr/bin/env python3
"""Proof-set overlap between variants and coverage by static order.
usage: complement.py RES.jsonl  (expects base, learn_s3, learn_s4, learn_s5, learn_v5|learn, learn_s3l, learn_s4l when present)"""
import sys, json, collections, statistics as st
R = collections.defaultdict(dict)
for l in open(sys.argv[1]):
    d = json.loads(l); R[d['variant']][d['instance']] = d
pr = lambda v: {i for i, d in R.get(v, {}).items() if d.get('optimal') or d.get('infeasible')}
on = 'learn_v5' if 'learn_v5' in R else 'learn'
S3, S4, S5, ON = pr('learn_s3'), pr('learn_s4'), pr('learn_s5'), pr(on)
print(f'online={on}: proven  s3 {len(S3)}  s4 {len(S4)}  s5 {len(S5)}  online {len(ON)}')
st4 = S3 | S4
print(f'static3 or static4: {len(st4)};  online only (not s3, not s4): {len(ON - st4)};  static only (s3 or s4, not online): {len(st4 - ON)}')
print(f'  s4 adds over s3: {len(S4 - S3)};  s3 proves but s4 does not: {len(S3 - S4)};  s5 adds over s3|s4: {len(S5 - st4) if S5 else "-"}; s3|s4 proves but s5 does not: {len(st4 - S5) if S5 else "-"}')
print(f'  union s3|s4|online: {len(st4 | ON)}')
for h in ('learn_s3l', 'learn_s4l'):
    if h in R:
        H = pr(h); U = (S3 if h.endswith('3l') else S4) | ON
        print(f'  {h}: {len(H)}; union of its parts {len(U)}; covered parts {len(H & U)}; new beyond union {len(H - U)}')
for v in ('learn_s3', 'learn_s4', 'learn_s5'):
    xs = [d['stats'] for d in R.get(v, {}).values() if 'stats' in d and d['stats'].get('static_certs')]
    if xs and 'static_used' in xs[0]:
        print(f'{v}: median static certificates {st.median(x["static_certs"] for x in xs):.0f}, median that ever prune {st.median(x["static_used"] for x in xs):.0f} '
              f'({100*st.median(x["static_used"]/x["static_certs"] for x in xs):.2f}% per run)')

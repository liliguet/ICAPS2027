"""CPU pinning helper: one allowed logical CPU per distinct physical core, handed out to workers."""
import os, queue
def physical_slots():
    allowed = sorted(os.sched_getaffinity(0)); seen = set(); slots = []
    for c in allowed:
        try:
            pkg = open(f'/sys/devices/system/cpu/cpu{c}/topology/physical_package_id').read().strip()
            core = open(f'/sys/devices/system/cpu/cpu{c}/topology/core_id').read().strip()
        except OSError:
            pkg, core = '?', str(c)
        if (pkg, core) not in seen: seen.add((pkg, core)); slots.append(c)
    return allowed, slots
def make_pool(jobs):
    allowed, slots = physical_slots()
    if len(slots) < jobs:
        print(f'[pin] only {len(slots)} distinct physical cores among {len(allowed)} allowed CPUs; using {jobs} jobs anyway (some share a core)')
        slots = (slots + [c for c in allowed if c not in slots])[:jobs]
    q = queue.Queue(); [q.put(c) for c in slots[:jobs]]
    print(f'[pin] allowed CPUs: {len(allowed)}, physical cores among them: {len(physical_slots()[1])}, pinning to {slots[:jobs]}')
    return q

#!/bin/bash
# Build Marijnissen et al.'s RPID+CP code (ICAPS 2026) and write a discovery report.
# Their Cargo paths expect   <root>/RPID, <root>/Pumpkin, <root>/RPID-models  (tsptw uses ../../RPID, ../../Pumpkin/pumpkin-solver).
# The Zenodo zips unpack one level deeper, so we COPY them into that layout (copies, not symlinks: cargo resolves paths after symlinks).
# usage: bash tools/build_cp.sh ZENODO_DIR [ROOT]     e.g. bash tools/build_cp.sh path/to/zenodo path/to/cpbuild
Z=$(realpath "${1:-zenodo}"); R=$(realpath -m "${2:-$HOME/work/cpbuild}"); OUT=$(pwd)/cp_report.txt
exec > >(tee "$OUT") 2>&1
source "$HOME/.cargo/env" 2>/dev/null
cd "$Z" || exit 1
for f in RPID.zip RPID-models.zip Pumpkin-RPID.zip RPID-CP-Results.zip; do d=${f%.zip}; [ -d "$d" ] || unzip -q -o "$f" -d "$d"; done
mkdir -p "$R"
[ -d "$R/RPID" ]        || cp -r "$Z"/RPID/*/ "$R/RPID"
[ -d "$R/Pumpkin" ]     || cp -r "$Z"/Pumpkin-RPID/*/ "$R/Pumpkin"
[ -d "$R/RPID-models" ] || cp -r "$Z"/RPID-models/*/ "$R/RPID-models"
[ -d "$R/Results" ]     || cp -r "$Z"/RPID-CP-Results/*/ "$R/Results"
echo "===== layout"; ls "$R" "$R/RPID" "$R/Pumpkin" "$R/RPID-models"
echo "===== toolchain pinned by Pumpkin"; cat "$R/Pumpkin/rust-toolchain.toml" 2>/dev/null
echo "===== tsptw sources"; ls -R "$R/RPID-models/tsptw/src" "$R/RPID-models/common/src"
echo "===== build (tsptw only)"
cd "$R/RPID-models" && timeout 3600 cargo build --release -p tsptw 2>&1 | tail -25
echo "===== binaries"; ls -la "$R/RPID-models/target/release" | grep -v '\.d$' | head -30
for b in $(find "$R/RPID-models/target/release" -maxdepth 1 -type f -executable); do echo "----- $b --help"; timeout 5 "$b" --help 2>&1 | head -60; done
echo "===== how they ran it (run_slurm.py)"; cat "$R/Results/run_slurm.py" 2>/dev/null | head -150
echo "===== tsptw benchmarks folders"; ls "$R/Results/tsptw/benchmarks"; for d in "$R"/Results/tsptw/benchmarks/*/; do echo "$d $(ls "$d" | wc -l) files; e.g. $(ls "$d" | head -3 | tr '\n' ' ')"; done
echo "===== select_rifki_solnon.py"; cat "$R/Results/tsptw/select_rifki_solnon.py" | head -80
echo "===== experiments.zip (tsptw) listing"; unzip -l "$R/Results/tsptw/experiments.zip" | head -40
echo "===== main.rs heads"; for f in $(find "$R/RPID-models/tsptw/src" -name '*.rs'); do echo "----- $f"; head -120 "$f"; done
echo "report written to $OUT"

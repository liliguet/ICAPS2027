"""Summarise lu_rpid runs. Instance names a{alpha}_b{beta}_s{seed}.txt are grouped into zones by beta;
other names go to one group. Paired comparisons use instances solved (proved) by every variant."""
import json, sys, re, collections, numpy as np
R = [json.loads(l) for l in open(sys.argv[1]) if l.strip()]
order = ['base', 'pair', 'learn', 'pair_learn']
allv = sorted({r['variant'] for r in R}, key=lambda v: (order.index(v) if v in order else 99, v))
V = [v for v in allv if v in (sys.argv[2].split(',') if len(sys.argv) > 2 else allv)]
by = collections.defaultdict(dict)
for r in R: by[r['instance']][r['variant']] = r
def zone(name):
    m = re.match(r'a([\d.]+)_b([\d.]+)_', name)
    if not m: return 'all'
    b = float(m.group(2))
    return 'tight b<=0.3' if b <= 0.3 + 1e-9 else ('transition 0.4-0.6' if b <= 0.6 + 1e-9 else 'loose b>=0.7')
proved = lambda r: r.get('ok') and (r.get('optimal') or r.get('infeasible'))
bad = [r for r in R if r.get('ok') and r.get('cost') is not None and not r.get('valid')]
print(f'{len(by)} instances, invalid solutions: {len(bad)}, crashed/timeout runs: {sum(not r.get("ok") for r in R)}')
for z in sorted({zone(k) for k in by}):
    ks = [k for k in by if zone(k) == z and all(v in by[k] for v in V)]
    both = [k for k in ks if all(proved(by[k][v]) for v in V)]
    print(f'\n== {z}: {len(ks)} instances; proved by all: {len(both)}')
    print(f'{"variant":11s} {"proved":>8s} {"opt":>4s} {"inf":>4s} {"sum time":>9s} {"geo time(all-proved)":>21s} {"geo expanded":>13s} {"certs":>7s} {"pr_single":>10s} {"pr_pair":>9s} {"pr_cert":>9s} {"t_pair":>7s} {"t_cert":>7s} {"t_extr":>7s}')
    for v in V:
        rs = [by[k][v] for k in ks]
        st = [r.get('stats', {}) for r in rs]
        g = lambda key: [by[k][v][key] for k in both]
        geo = lambda xs: float(np.exp(np.mean(np.log(np.maximum(xs, 1e-3))))) if xs else float('nan')
        print(f'{v[:11]:11s} {sum(bool(proved(r)) for r in rs):4d}/{len(rs):<3d} {sum(bool(r.get("optimal")) for r in rs):4d} {sum(bool(r.get("infeasible")) for r in rs):4d}'
              f' {sum(r.get("time", 0) for r in rs):9.1f} {geo(g("time")):21.3f} {geo(g("expanded")):13.0f}'
              f' {np.mean([s.get("certs", 0) for s in st]):7.1f} {sum(s.get("pruned_single", 0) for s in st):10d} {sum(s.get("pruned_pair", 0) for s in st):9d} {sum(s.get("pruned_cert", 0) for s in st):9d}'
              f' {sum(s.get("t_pair", 0) for s in st):7.1f} {sum(s.get("t_cert", 0) for s in st):7.1f} {sum(s.get("t_extract", 0) for s in st):7.1f}')

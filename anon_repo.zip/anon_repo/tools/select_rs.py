"""Select Rifki & Solnon (JAIR 2025) instances and copy them into RPID format.
The original files (ins_n_{n}_alph_{a}_beta_{b}_{k}.txt) already use the RPID layout
(n, n x n matrix, n lines 'ready due'), so this only selects, validates and renames to a{a}_b{b}_s{k}.txt.

Sets (as in Marijnissen et al., ICAPS 2026):
  general : alpha in {1.0,1.5,2.0,2.5,3.0}, beta in {0.2,...,1.0}, 3 instances per cell  (135)
  tight   : alpha in {1.0,1.1,...,1.5},     beta in {0.2,...,1.0}, 10 instances per cell (540)
usage: python3 select_rs.py SRC_DIR OUT_DIR --set tight|general|all [--n 31]"""
import argparse, os, re, glob, shutil
ap = argparse.ArgumentParser()
ap.add_argument('src'); ap.add_argument('out'); ap.add_argument('--set', default='tight'); ap.add_argument('--n', type=int, default=None)
a = ap.parse_args()
betas = [round(0.2 + 0.1 * i, 2) for i in range(9)]
sets = dict(general=([1.0, 1.5, 2.0, 2.5, 3.0], betas, range(1, 4)),
            tight=([1.0, 1.1, 1.2, 1.3, 1.4, 1.5], betas, range(1, 11)))
os.makedirs(a.out, exist_ok=True)
pat = re.compile(r'n_(\d+)_alph_([\d.]+)_beta_([\d.]+)_(\d+)\.txt$')
files = glob.glob(os.path.join(a.src, '**', '*.txt'), recursive=True)
cnt = 0
for f in files:
    m = pat.search(os.path.basename(f))
    if not m: continue
    n, al, be, k = int(m.group(1)), float(m.group(2)), float(m.group(3)), int(m.group(4))
    if a.n and n != a.n: continue
    if a.set != 'all':
        A, B, K = sets[a.set]
        if not (any(abs(al - x) < 1e-6 for x in A) and any(abs(be - x) < 1e-6 for x in B) and k in K): continue
    v = open(f).read().split(); nn = int(v[0])
    assert len(v) == 1 + nn * nn + 2 * nn, f'unexpected layout in {f}'
    shutil.copy(f, os.path.join(a.out, f'a{al:.2f}_b{be:.2f}_s{k}.txt')); cnt += 1
print(a.out, cnt, 'instances')

#!/usr/bin/env python3
"""Coverage and paired times for groups of variants. usage: agg_v14.py RES.jsonl v1,v2,... [v1,v2,...]..."""
import sys, json, math, collections
R = collections.defaultdict(dict)
for l in open(sys.argv[1]):
    d = json.loads(l); R[d['variant']][d['instance']] = d
pr = lambda d: bool(d.get('optimal') or d.get('infeasible'))
for grp in sys.argv[2:]:
    vs = grp.split(','); print('==', grp)
    for v in vs:
        X = R.get(v, {}); o = sum(1 for d in X.values() if d.get('optimal')); f = sum(1 for d in X.values() if d.get('infeasible'))
        fail = sum(1 for d in X.values() if not d.get('ok', True))
        print(f'  {v:24s} runs {len(X):4d}  opt {o:4d}  inf {f:4d}  proven {o+f:4d}  crashed/memout {fail}')
    com = set.intersection(*[{i for i, d in R.get(v, {}).items() if pr(d)} for v in vs])
    if com:
        print(f'  common proven: {len(com)}')
        for v in vs:
            g = math.exp(sum(math.log(max(R[v][i]['time'], 1e-4)) for i in com) / len(com))
            e = math.exp(sum(math.log(max(R[v][i]['expanded'], 1)) for i in com) / len(com))
            print(f'  {v:24s} geo time {g:8.3f}  geo expanded {e:12.0f}')

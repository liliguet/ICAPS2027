"""Run lu_rpid on every instance file in a directory for each variant; one JSON line per run.
   usage: python3 run_all.py BIN DIR OUT.jsonl --variants base,pair,learn,pair_learn --time-limit 60 --jobs 4"""
import argparse, subprocess, json, os, glob, concurrent.futures as cf
ap = argparse.ArgumentParser()
ap.add_argument('bin'); ap.add_argument('dir'); ap.add_argument('out')
ap.add_argument('--variants', default='base,pair,learn,pair_learn')
ap.add_argument('--time-limit', type=float, default=60); ap.add_argument('--jobs', type=int, default=1)
ap.add_argument('--astar', action='store_true'); ap.add_argument('--extra', default='', help='extra solver args, e.g. "--no-index"'); ap.add_argument('--tag', default='', help='suffix added to the variant name in the output'); ap.add_argument('--pin', action='store_true', help='pin each worker to its own physical core'); ap.add_argument('--memlimit-gb', type=float, default=8); ap.add_argument('--history-dir', default='', help='save per-run anytime history CSVs here')
a = ap.parse_args()
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
from pinning import make_pool
PINQ = make_pool(a.jobs) if a.pin else None
files = sorted(glob.glob(os.path.join(a.dir, '*.txt')))
done = set()
if os.path.exists(a.out):
    for l in open(a.out):
        r = json.loads(l); done.add((r['instance'], r['variant']))
os.makedirs(a.history_dir, exist_ok=True) if a.history_dir else None
tasks = [(f, v) for f in files for v in a.variants.split(',') if (os.path.basename(f), v + a.tag) not in done]
def run(fv):
    f, v = fv
    hist = os.path.join(a.history_dir, f"{os.path.basename(f)[:-4]}__{v}{a.tag}.csv") if a.history_dir else '/dev/null'
    cmd = [a.bin, f, '--variant', v, '--time-limit', str(a.time_limit), '--history', hist] + (['--astar'] if a.astar else []) + a.extra.split()
    lim = f"ulimit -v {int(a.memlimit_gb * 1024 * 1024)}; "
    cpu = PINQ.get() if PINQ else None
    if cpu is not None: cmd = ['taskset', '-c', str(cpu)] + cmd
    try:
        p = subprocess.run(['bash', '-c', lim + ' '.join(cmd)], capture_output=True, text=True, timeout=a.time_limit * 2 + 60)
        out = p.stdout
    except subprocess.TimeoutExpired:
        out = ''
    if cpu is not None: PINQ.put(cpu)
    r = dict(instance=os.path.basename(f), variant=v + a.tag, ok=False)
    for line in out.splitlines():
        if line.startswith('RESULT '): r.update(json.loads(line[7:])); r['variant'] = v + a.tag; r['ok'] = True
        if line.startswith('STATS '): r['stats'] = json.loads(line[6:])
        if line.startswith('TRACE '): r['trace'] = json.loads(line[6:])
    if not r['ok']: r['stderr'] = (p.stderr[-500:] if 'p' in dir() else 'timeout')
    return r
with open(a.out, 'a') as fo, cf.ThreadPoolExecutor(a.jobs) as ex:
    for r in ex.map(run, tasks):
        fo.write(json.dumps(r) + '\n'); fo.flush()
        print(r['instance'], r['variant'], r.get('cost'), 'opt' if r.get('optimal') else '', 'inf' if r.get('infeasible') else '',
              f"t={r.get('time', 0):.2f}", 'exp', r.get('expanded'), 'valid', r.get('valid'), flush=True)

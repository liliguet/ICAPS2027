"""Summarise TRACE lines: where certificates were learned vs where they pruned.
Pooled shares (all prunes of all runs) AND per-instance distributions (median, quartiles), so that a few
hard instances cannot dominate. 'earlier round' = learned in any earlier round; 'previous round' = exactly
the round before."""
import json, sys, collections, numpy as np
R = [json.loads(l) for l in open(sys.argv[1]) if l.strip()]
v = sys.argv[2] if len(sys.argv) > 2 else 'learn'
pool = collections.Counter(); per = []; D = collections.Counter()
for r in R:
    if r['variant'] != v or 'trace' not in r: continue
    c = collections.Counter()
    for lr, ur, k in r['trace']['round']:
        c['tot'] += k; c['earlier'] += k * (ur > lr); c['prev'] += k * (ur == lr + 1); c['same'] += k * (ur == lr)
    for ld, ud, k in r['trace']['depth']:
        c['dtot'] += k; c['shallower'] += k * (ud < ld); c['deeper'] += k * (ud > ld); D[(ld, ud)] += k
    pool.update(c)
    if c['tot'] > 0: per.append((c['earlier'] / c['tot'], c['prev'] / c['tot'], c['shallower'] / max(c['dtot'], 1)))
print(f'{v}: {len(per)} runs with certificate prunes, {pool["tot"]} prunes in total')
if pool['tot']:
    print(f'  pooled : earlier round {100*pool["earlier"]/pool["tot"]:.1f}% | previous round {100*pool["prev"]/pool["tot"]:.1f}% | same round {100*pool["same"]/pool["tot"]:.1f}% | shallower {100*pool["shallower"]/pool["dtot"]:.1f}% | deeper {100*pool["deeper"]/pool["dtot"]:.1f}%')
    P = np.array(per)
    for i, name in enumerate(['earlier round', 'previous round', 'shallower depth']):
        q = np.percentile(P[:, i], [25, 50, 75]) * 100
        print(f'  per-instance share, {name:15s}: median {q[1]:.1f}%  (IQR {q[0]:.1f}-{q[2]:.1f}%)')
    md = max(max(a, b) for a, b in D) + 1
    M = np.zeros((md, md), int)
    for (a, b), k in D.items(): M[a, b] = k
    np.savetxt(sys.argv[1] + f'.{v}.depth_matrix.csv', M, fmt='%d', delimiter=',')
    print('  depth matrix (rows=learn depth, cols=use depth) saved to', sys.argv[1] + f'.{v}.depth_matrix.csv')

"""Convert Dumas-format instances (LMask/data/dumas: locations/*.txt, distances/*.txt) to RPID format.
Service times are added to outgoing travel times (standard reduction), as in icaps_run/instances.py."""
import os, sys, numpy as np
src, out = sys.argv[1], sys.argv[2]; os.makedirs(out, exist_ok=True)
for fn in sorted(os.listdir(os.path.join(src, 'locations'))):
    name = fn[:-4]; locs, st, tw = [], [], []
    for line in open(os.path.join(src, 'locations', fn)):
        p = line.split()
        if len(p) == 7 and p[0] != '999':
            try: v = [float(x) for x in p]
            except ValueError: continue
            locs.append(v[1:3]); tw.append(v[4:6]); st.append(v[6])
    locs, st, tw = np.array(locs), np.array(st), np.array(tw)
    df = os.path.join(src, 'distances', fn)
    if os.path.exists(df):
        L = open(df).read().split(); n = int(L[0]); D = np.array(L[1:1 + n * n], float).reshape(n, n)
    else:
        D = np.floor(np.sqrt(((locs[:, None] - locs[None]) ** 2).sum(-1)))
    D = D + st[:, None]; np.fill_diagonal(D, 0)
    with open(os.path.join(out, name + '.txt'), 'w') as f:
        f.write(f'{len(D)}\n'); [f.write(' '.join(str(int(round(x))) for x in r) + '\n') for r in D]
        [f.write(f'{int(round(a))} {int(round(b))}\n') for a, b in tw]
print(out)

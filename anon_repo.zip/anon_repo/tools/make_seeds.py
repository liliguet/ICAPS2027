"""Copy the instances with seed in S (e.g. 1-5) from DIR to OUT (fixed rule, independent of results)."""
import os, sys, re, shutil
src, out, lo, hi = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4]); os.makedirs(out, exist_ok=True); c = 0
for f in os.listdir(src):
    m = re.match(r'a[\d.]+_b([\d.]+)_s(\d+)\.txt$', f)
    if m and lo <= int(m.group(2)) <= hi and float(m.group(1)) >= 0.4 - 1e-9: shutil.copy(os.path.join(src, f), out); c += 1
print(out, c)

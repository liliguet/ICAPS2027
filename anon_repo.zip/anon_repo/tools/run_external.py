"""Run any RPID-based binary that prints RPID's standard statistics (cost / optimal cost / The problem is
infeasible / best bound / Search time / Expanded / Generated), e.g. Marijnissen et al.'s tsptw(+CP) binary.
Writes the same jsonl schema as run_all.py, so tools/agg.py can compare everything in one table.
usage: python3 run_external.py DIR OUT.jsonl --name cabs_cp --cmd "/path/bin {inst} --time-limit {tl} ..." --time-limit 300 --jobs 8"""
import argparse, subprocess, json, os, glob, re, concurrent.futures as cf, sys
sys.path.insert(0, os.path.dirname(__file__))
ap = argparse.ArgumentParser()
ap.add_argument('dir'); ap.add_argument('out'); ap.add_argument('--name', required=True); ap.add_argument('--cmd', required=True)
ap.add_argument('--time-limit', type=float, default=300); ap.add_argument('--jobs', type=int, default=1); ap.add_argument('--validator', default='tsptw', choices=['tsptw', 'wttw', 'none']); ap.add_argument('--pin', action='store_true', help='pin each worker to its own physical core'); ap.add_argument('--memlimit-gb', type=float, default=16); ap.add_argument('--history-dir', default='', help='if set, {hist} in --cmd is replaced by a per-run CSV path')
a = ap.parse_args()
import sys as _s, os as _o; _s.path.insert(0, _o.path.dirname(_o.path.abspath(__file__)))
from pinning import make_pool
PINQ = make_pool(a.jobs) if a.pin else None

def validate_wttw(path, seq, cost):
    v = list(map(int, open(path).read().split())); n = v[0]; J = [v[1 + 5 * i:6 + 5 * i] for i in range(n)]   # p d w r dl
    if sorted(seq) != list(range(n)): return False
    t = tot = 0
    for j in seq:
        p, d, w, r, dl = J[j]; t = max(t, r) + p
        if t > dl: return False
        tot += w * max(0, t - d)
    return tot == cost

def validate(path, tour, cost):
    v = open(path).read().split(); n = int(v[0]); D = [list(map(int, v[1 + i * n:1 + (i + 1) * n])) for i in range(n)]
    tw = [(int(v[1 + n * n + 2 * i]), int(v[2 + n * n + 2 * i])) for i in range(n)]
    if sorted(tour) != list(range(1, n)): return False
    t, cur, tot = max(tw[0][0], 0), 0, 0
    for nx in tour + [0]:
        t = max(t + D[cur][nx], tw[nx][0]); tot += D[cur][nx]
        if t > tw[nx][1]: return False
        cur = nx
    return tot == cost

files = sorted(glob.glob(os.path.join(a.dir, '*.txt')))
done = set()
if os.path.exists(a.out):
    for l in open(a.out): r = json.loads(l); done.add((r['instance'], r['variant']))
os.makedirs(a.history_dir, exist_ok=True) if a.history_dir else None
tasks = [f for f in files if (os.path.basename(f), a.name) not in done]
def run(f):
    hist = os.path.join(a.history_dir, f"{os.path.basename(f)[:-4]}__{a.name}.csv") if a.history_dir else '/dev/null'
    cmd = a.cmd.format(inst=f, tl=a.time_limit, hist=hist)
    lim = f"ulimit -v {int(a.memlimit_gb * 1024 * 1024)}; "
    cpu = PINQ.get() if PINQ else None
    if cpu is not None: cmd = f'taskset -c {cpu} ' + cmd
    try:
        p = subprocess.run(['bash', '-c', lim + cmd], capture_output=True, text=True, timeout=a.time_limit * 2 + 120); out, err = p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        out, err = '', 'timeout'
    if cpu is not None: PINQ.put(cpu)
    r = dict(instance=os.path.basename(f), variant=a.name, ok=False, optimal=False, infeasible=False, cost=None, best_bound=None)
    for line in out.splitlines():
        L = line.strip(); low = L.lower()
        if low.startswith('%%%mzn'): continue                       # Pumpkin statistics block
        if m := re.match(r'(?:best )?cost\s*[:=]\s*(-?\d+)', low): r['cost'] = int(m.group(1)); r['ok'] = True
        if low.startswith('optimal'):
            r['optimal'] = True
            if m := re.search(r'(-?\d+)\s*$', low): r['cost'] = int(m.group(1))
        if 'infeasible' in low and ('problem' in low or 'instance' in low): r['infeasible'] = True; r['ok'] = True
        if low.startswith('no solution'): r['ok'] = True
        if m := re.match(r'(?:best )?(?:dual )?bound\s*[:=]\s*(-?\d+)', low): r['best_bound'] = int(m.group(1))
        if m := re.match(r'(?:search )?time\s*[:=]\s*([\d.eE+-]+)\s*s?', low): r['time'] = float(m.group(1)); r['ok'] = True
        if m := re.match(r'expanded\s*[:=]\s*(\d+)', low): r['expanded'] = int(m.group(1))
        if m := re.match(r'generated\s*[:=]\s*(\d+)', low): r['generated'] = int(m.group(1))
        if m := re.match(r'(tour|transitions|solution|schedule)\s*:\s*([\d ]+)$', low): r['tour'] = list(map(int, m.group(2).split()))
    if r['cost'] is None and 'tour' in r and a.validator == 'tsptw':                           # recover the cost from the tour
        v = open(f).read().split(); n = int(v[0]); D = [list(map(int, v[1 + i * n:1 + (i + 1) * n])) for i in range(n)]
        seq = [0] + r['tour'] + [0]; r['cost'] = sum(D[seq[i]][seq[i + 1]] for i in range(len(seq) - 1)); r['ok'] = True
    if r['ok'] and (r.get('time') is None or (r['cost'] is None and not r['infeasible'])):
        r['stdout_head'] = out[:3000]                               # keep raw output so the parser can be checked
    if r['cost'] is not None and 'tour' in r and a.validator != 'none':
        r['valid'] = (validate if a.validator == 'tsptw' else validate_wttw)(f, r['tour'], r['cost'])
    elif r['cost'] is not None: r['valid'] = None
    if not r['ok']: r['stderr'] = err[-800:]; r['stdout'] = out[-800:]
    return r
with open(a.out, 'a') as fo, cf.ThreadPoolExecutor(a.jobs) as ex:
    for r in ex.map(run, tasks):
        fo.write(json.dumps(r) + '\n'); fo.flush()
        print(r['instance'], a.name, r.get('cost'), 'opt' if r['optimal'] else '', 'inf' if r['infeasible'] else '', f"t={r.get('time', 0):.2f}", 'exp', r.get('expanded'), 'valid', r.get('valid'), '' if r['ok'] else 'FAILED', flush=True)

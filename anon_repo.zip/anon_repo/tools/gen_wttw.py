"""Random 1|r_j,dl_j|sum w_j T_j instances in the normalized format (n, then 'r p d dl w' per job).
Used only for correctness tests; the experiments use Marijnissen et al.'s benchmark (see wttw_convert.py).
r ~ U[0, R*P], d = r + p + U[0, T*P], dl = d + U[0, D*P], with P = sum p, p,w ~ U[1,10]."""
import sys, os, random
out, cnt, n = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]); os.makedirs(out, exist_ok=True)
rng = random.Random(1)
for k in range(cnt):
    R, T, D = rng.choice([0.2, 0.5, 0.8]), rng.choice([0.1, 0.3, 0.6]), rng.choice([0.2, 0.5, 1.0])
    p = [rng.randint(1, 10) for _ in range(n)]; P = sum(p)
    rows = []
    for j in range(n):
        r = rng.randint(0, int(R * P)); d = r + p[j] + rng.randint(0, int(T * P)); dl = d + rng.randint(0, int(D * P))
        rows.append((r, p[j], d, dl, rng.randint(1, 10)))
    with open(os.path.join(out, f'w{k:03d}.txt'), 'w') as f:
        f.write(f'{n}\n'); [f.write(' '.join(map(str, r)) + '\n') for r in rows]

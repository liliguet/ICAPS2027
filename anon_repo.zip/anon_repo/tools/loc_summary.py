#!/usr/bin/env python3
"""Share of certificate prunes that a location-bound store could not have made.
usage: loc_summary.py RES.jsonl [variant]"""
import json, sys, statistics as st
v = sys.argv[2] if len(sys.argv) > 2 else 'learn_locstats'
P = {'loc_same': 0, 'loc_other': 0, 'loc_other_only': 0}; per = []; n = 0
for l in open(sys.argv[1]):
    r = json.loads(l)
    if r.get('variant') != v or 'stats' not in r: continue
    s = r['stats']; n += 1
    tot = s['loc_same'] + s['loc_other'] + s['loc_other_only']
    for k in P: P[k] += s[k]
    if tot: per.append((s['loc_same'] / tot, (s['loc_other'] + s['loc_other_only']) / tot, s['loc_other_only'] / tot))
T = sum(P.values())
print(f'{v}: {n} runs, {len(per)} with certificate prunes, {T} prunes')
print('pooled: fired cert learned at same location %.1f%% | learned elsewhere %.1f%% | no same-location cert fires %.1f%%'
      % (100 * P['loc_same'] / T, 100 * (P['loc_other'] + P['loc_other_only']) / T, 100 * P['loc_other_only'] / T))
for i, name in enumerate(['same location', 'learned elsewhere', 'no same-location cert fires']):
    q = st.quantiles([p[i] for p in per], n=4)
    print(f'  per-run {name:28s}: median {100*st.median([p[i] for p in per]):.1f}%  (IQR {100*q[0]:.1f}-{100*q[2]:.1f}%)')

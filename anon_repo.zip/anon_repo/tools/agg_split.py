"""Results split by instance class, plus paired comparisons and anytime proof curves.
class: 'infeasible' if any method proved infeasibility, 'feasible' if any method found a solution, else 'unknown'.
usage: python3 agg_split.py RES.jsonl [variants,comma,separated] [--curves OUT.csv]"""
import json, sys, re, collections, numpy as np
args = [a for a in sys.argv[1:] if not a.startswith('--')]
curves = sys.argv[sys.argv.index('--curves') + 1] if '--curves' in sys.argv else None
if curves in args: args.remove(curves)
R = [json.loads(l) for l in open(args[0]) if l.strip()]
by = collections.defaultdict(dict)
for r in R: by[r['instance']][r['variant']] = r
allv = sorted({r['variant'] for r in R})
V = args[1].split(',') if len(args) > 1 else allv
proved = lambda r: bool(r.get('ok') and (r.get('optimal') or r.get('infeasible')))
def cls(d):
    if any(r.get('infeasible') for r in d.values()): return 'infeasible'
    if any(r.get('cost') is not None for r in d.values()): return 'feasible'
    return 'unknown'
def zone(name):
    m = re.match(r'a([\d.]+)_b([\d.]+)_', name)
    if not m:
        m2 = re.search(r'rho_([\d.]+)', name)
        return f'rho={m2.group(1)}' if m2 else 'all'
    b = float(m.group(2)); return 'tight' if b <= 0.3 + 1e-9 else ('transition' if b <= 0.6 + 1e-9 else 'loose')
ks_all = [k for k in by if all(v in by[k] for v in V)]
conf = [k for k in ks_all if any(by[k][v].get('infeasible') for v in by[k]) and any(by[k][v].get('cost') is not None for v in by[k])]
print(f'{len(ks_all)} instances with all of {V}; infeasible-vs-solution conflicts: {len(conf)}')
for z in sorted({zone(k) for k in ks_all}):
    for c in ['infeasible', 'feasible', 'unknown']:
        ks = [k for k in ks_all if zone(k) == z and cls(by[k]) == c]
        if not ks: continue
        print(f'\n== zone={z} class={c}: {len(ks)} instances')
        print(f'{"variant":16s} {"proved":>9s} {"has sol":>8s} {"sum time":>9s} {"geo time (all proved)":>22s}')
        allp = [k for k in ks if all(proved(by[k][v]) for v in V)]
        for v in V:
            rs = [by[k][v] for k in ks]
            g = [by[k][v]['time'] for k in allp]
            geo = float(np.exp(np.mean(np.log(np.maximum(g, 1e-4))))) if g else float('nan')
            print(f'{v[:16]:16s} {sum(proved(r) for r in rs):4d}/{len(rs):<4d} {sum(r.get("cost") is not None for r in rs):8d} {sum(r.get("time", 0) for r in rs):9.1f} {geo:16.3f} (n={len(allp)})')
        if c == 'feasible':
            un = [k for k in ks if not any(proved(by[k][v]) for v in V)]
            if un:
                print(f'   common unsolved feasible ({len(un)}): mean primal/dual gap per method (same instances)')
                for v in V:
                    gs = [(by[k][v]['cost'] - by[k][v]['best_bound']) / by[k][v]['cost'] for k in un if by[k][v].get('cost') and by[k][v].get('best_bound') is not None]
                    pc = [by[k][v]['cost'] for k in un if by[k][v].get('cost')]
                    print(f'   {v[:16]:16s} gap {100 * np.mean(gs) if gs else float("nan"):6.2f}%  (n={len(gs)})')
if curves:
    with open(curves, 'w') as f:
        f.write('variant,class,time,cum_proved\n')
        for v in V:
            for c in ['infeasible', 'feasible']:
                ts = sorted(by[k][v]['time'] for k in ks_all if cls(by[k]) == c and proved(by[k][v]))
                for i, t in enumerate(ts): f.write(f'{v},{c},{t:.6f},{i + 1}\n')
    print('curves written to', curves)

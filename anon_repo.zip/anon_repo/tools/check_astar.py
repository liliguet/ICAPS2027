#!/usr/bin/env python3
"""Correctness check for the A* host: A* base / A* learn / A* locset must agree with CABS base on every
instance that both prove (same optimal cost or both infeasible). usage: check_astar.py BIN DIR [N] [TL]"""
import sys, glob, os, subprocess, json
b, d = sys.argv[1], sys.argv[2]; n = int(sys.argv[3]) if len(sys.argv) > 3 else 30; tl = sys.argv[4] if len(sys.argv) > 4 else '60'
def run(f, extra):
    out = subprocess.run([b, f, '--time-limit', tl] + extra, capture_output=True, text=True).stdout
    for l in out.splitlines():
        if l.startswith('RESULT '): return json.loads(l[7:])
    return None
files = sorted(glob.glob(os.path.join(d, '*.txt')))[:n]; bad = 0; agree = 0
for f in files:
    ref = run(f, ['--variant', 'base'])
    for extra in (['--variant', 'base', '--astar'], ['--variant', 'learn', '--astar'], ['--variant', 'learn', '--astar', '--cert-mode', 'locset'], ['--variant', 'learn', '--cert-mode', 'locset']):
        r = run(f, extra)
        if not ref or not r: continue
        p1 = ref['optimal'] or ref['infeasible']; p2 = r['optimal'] or r['infeasible']
        if p1 and p2:
            ok = (ref['infeasible'] == r['infeasible']) and (ref['cost'] == r['cost'])
            agree += ok; bad += (not ok)
            if not ok: print('MISMATCH', os.path.basename(f), ' '.join(extra), ref['cost'], ref['infeasible'], r['cost'], r['infeasible'])
        if r.get('valid') is False: bad += 1; print('INVALID', os.path.basename(f), ' '.join(extra))
print(f'agreements {agree}, mismatches/invalid {bad}')

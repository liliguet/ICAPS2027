"""Exact optimum by label DP over subsets (small n); writes {instance: cost or null}."""
import sys, os, glob, json
def solve(path):
    v = list(map(int, open(path).read().split())); n = v[0]; J = [v[1 + 5 * i:6 + 5 * i] for i in range(n)]
    lab = {0: [(0, 0)]}                                   # mask -> pareto list of (t, cost)
    for size in range(n):
        new = {}
        for S, L in lab.items():
            if bin(S).count('1') != size: continue
            for j in range(n):
                if S >> j & 1: continue
                r, p, d, dl, w = J[j]
                for t, c in L:
                    C = max(t, r) + p
                    if C <= dl: new.setdefault(S | 1 << j, []).append((C, c + w * max(0, C - d)))
        for k, L in new.items():
            L.sort(); out = []; best = 1 << 60
            for t, c in L:
                if c < best: out.append((t, c)); best = c
            new[k] = out
        lab = new
    L = lab.get((1 << n) - 1)
    return min(c for t, c in L) if L else None
d = sys.argv[1]
ref = {os.path.basename(f): solve(f) for f in sorted(glob.glob(os.path.join(d, '*.txt')))}
json.dump(ref, open(sys.argv[2], 'w')); print(len(ref), 'feasible', sum(v is not None for v in ref.values()))

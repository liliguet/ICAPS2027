#!/usr/bin/env python3
"""Extract a pre-fixed grid of Rifki-Solnon instances from the authors' zip and name them like our sets.
usage: prep_rs.py ZIP OUTDIR --alphas 1.0,1.1,... --betas 0.4,... --seeds 1-5 [--compare DIR]"""
import argparse, zipfile, re, os, collections, filecmp
ap = argparse.ArgumentParser(); ap.add_argument('zip'); ap.add_argument('out')
ap.add_argument('--alphas', default='1.0,1.1,1.2,1.3,1.4,1.5'); ap.add_argument('--betas', default='0.4,0.5,0.6,0.7,0.8')
ap.add_argument('--seeds', default='1-5'); ap.add_argument('--compare', default='')
a = ap.parse_args()
z = zipfile.ZipFile(a.zip); pat = re.compile(r'alph_([\d.]+)_beta_([\d.]+)_(\d+)\.txt$')
avail = {}
for nm in z.namelist():
    m = pat.search(nm)
    if m: avail[(round(float(m.group(1)), 2), round(float(m.group(2)), 2), int(m.group(3)))] = nm
al = sorted({k[0] for k in avail}); be = sorted({k[1] for k in avail}); se = sorted({k[2] for k in avail})
print(f'{len(avail)} instances; alphas {al[:12]}{"..." if len(al)>12 else ""}; betas {be[:25]}; seeds {se}')
print('example name:', next(iter(avail.values())) if avail else None)
A = [round(float(x), 2) for x in a.alphas.split(',')]; B = [round(float(x), 2) for x in a.betas.split(',')]
s0, s1 = map(int, a.seeds.split('-')); S = range(s0, s1 + 1)
os.makedirs(a.out, exist_ok=True); miss = []; n = 0
for al_ in A:
    for b_ in B:
        for s_ in S:
            k = (al_, b_, s_)
            if k not in avail: miss.append(k); continue
            open(os.path.join(a.out, f'a{al_:.2f}_b{b_:.2f}_s{s_}.txt'), 'wb').write(z.read(avail[k])); n += 1
print(f'wrote {n} instances to {a.out}; missing {len(miss)}: {miss[:10]}')
if a.compare:
    same = diff = absent = 0
    for f in sorted(os.listdir(a.out)):
        g = os.path.join(a.compare, f)
        if not os.path.exists(g): absent += 1
        elif open(g).read().split() == open(os.path.join(a.out, f)).read().split(): same += 1
        else: diff += 1
    print(f'compare with {a.compare}: identical (up to whitespace) {same}, different {diff}, not present {absent}')

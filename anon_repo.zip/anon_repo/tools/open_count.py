#!/usr/bin/env python3
"""Count instances per class over all variants in a result file.
usage: open_count.py res_n41.jsonl [res_n51.jsonl ...]"""
import json, sys
for f in sys.argv[1:]:
    inf, sol, inst = set(), set(), set()
    for line in open(f):
        r = json.loads(line); i = r["instance"]; inst.add(i)
        if r.get("infeasible"): inf.add(i)
        if r.get("cost") is not None: sol.add(i)
    print(f, "instances", len(inst), "infeasible", len(inf), "solution known", len(sol),
          "conflicts", len(inf & sol), "open", len(inst - inf - sol))

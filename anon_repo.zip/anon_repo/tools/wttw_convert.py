"""Convert Marijnissen et al.'s WTTW benchmark (benchmarks/<Set>/<combo>/instance_k.txt) into two flat directories
with identical file names, so that results of both solvers can be paired by name:
  OUT_OURS/<combo>__instance_k.txt   normalized format for target/release/wttw  (n, then 'r p d dl w')
  OUT_THEIRS/<combo>__instance_k.txt original format for wttw_rpid            (n, then 'p d w r dl')
Original column meaning (from their instance.rs): p, due date d (tardiness), weight w, release r, hard deadline dl.
Selection is fixed in advance: --per-combo K keeps instance_0..instance_{K-1} of every parameter combination."""
import argparse, os, re, glob, shutil
ap = argparse.ArgumentParser()
ap.add_argument('root', help='.../Results/wttw/benchmarks'); ap.add_argument('out_ours'); ap.add_argument('out_theirs')
ap.add_argument('--sets', default='General,Extended'); ap.add_argument('--per-combo', type=int, default=3)
a = ap.parse_args()
os.makedirs(a.out_ours, exist_ok=True); os.makedirs(a.out_theirs, exist_ok=True); cnt = 0
for st in a.sets.split(','):
    for f in sorted(glob.glob(os.path.join(a.root, st, '*', 'instance_*.txt'))):
        k = int(re.search(r'instance_(\d+)\.txt$', f).group(1))
        if k >= a.per_combo: continue
        combo = os.path.basename(os.path.dirname(f)); name = f'{combo}__instance_{k}.txt'
        v = list(map(int, open(f).read().split())); n = v[0]; assert len(v) == 1 + 5 * n, f
        rows = [v[1 + 5 * i:6 + 5 * i] for i in range(n)]              # p d w r dl
        with open(os.path.join(a.out_ours, name), 'w') as g:
            g.write(f'{n}\n'); [g.write(f'{r} {p} {d} {dl} {w}\n') for p, d, w, r, dl in rows]
        shutil.copy(f, os.path.join(a.out_theirs, name)); cnt += 1
print(cnt, 'instances ->', a.out_ours, a.out_theirs)

"""All figures of the paper. usage: python3 make_figs.py MAIN_RES.jsonl ABL_RES.jsonl OUTDIR"""
import json, sys, collections, numpy as np, matplotlib
matplotlib.use('Agg')
matplotlib.rcParams.update({'pdf.fonttype': 42, 'ps.fonttype': 42, 'font.size': 7, 'font.family': 'serif', 'mathtext.fontset': 'stix'})
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from matplotlib.patches import FancyArrowPatch, Rectangle
main_res, abl_res, out = sys.argv[1], sys.argv[2], sys.argv[3]
proved = lambda r: bool(r.get('optimal') or r.get('infeasible'))

# ---------------- Figure 1: one conflict, several states ----------------
fig = plt.figure(figsize=(7.0, 1.95))
gs = fig.add_gridspec(1, 3, width_ratios=[1.35, 1.0, 1.05], wspace=0.35)
a = fig.add_subplot(gs[0]); a.set_xlim(0, 10); a.set_ylim(-0.6, 6); a.axis('off')
a.set_title('(a) Different states', fontsize=7.5)
U = {'u': (8.6, 4.6), 'v': (8.6, 1.4)}
S = {'p': ((4.3, 3.0), 3, {'u': 5, 'v': 3}, '#d62728'), 'q': ((3.0, 5.2), 1, {'u': 8, 'v': 6}, '#9467bd'), 'r': ((3.0, 0.8), 0, {'u': 7, 'v': 9}, '#2ca02c')}
wb = dict(boxstyle='round,pad=0.08', fc='white', ec='none')
for name, (xy, t, d, c) in S.items():
    a.plot([0.4, xy[0] - 1.4, xy[0]], [3.0, xy[1] * 0.6 + 1.2, xy[1]], color='0.78', lw=1.1, zorder=1)       # grey prefix
    a.scatter(*xy, s=34, color=c, zorder=3); a.text(xy[0] - 0.3, xy[1] + 0.4, f'${name}$, $t={t}$', fontsize=6.5, ha='right')
    for k, (ux, uy) in U.items():
        a.annotate('', xy=(ux, uy), xytext=xy, arrowprops=dict(arrowstyle='->', color=c, lw=0.55, ls=(0, (3, 2)), shrinkA=3.5, shrinkB=5.5))
        f = 0.3
        mx, my = xy[0] + f * (ux - xy[0]), xy[1] + f * (uy - xy[1])
        a.text(mx, my + (0.25 if uy > xy[1] else -0.45), f'{d[k]}', fontsize=5.6, color=c, ha='center', bbox=wb, zorder=4)
a.scatter([0.4], [3.0], marker='s', s=28, color='k'); a.text(0.4, 2.4, 'depot', fontsize=6, ha='center')
for k, (x, y) in U.items():
    a.scatter(x, y, s=70, color='#1f77b4', zorder=3); a.text(x + 0.4, y - 0.15, f'${k}$', fontsize=8)
a.plot([U['u'][0]] * 2, [U['u'][1] - 0.38, U['v'][1] + 0.38], color='#1f77b4', lw=0.8); a.text(9.05, 3.0, r'$c^*_{uv}=c^*_{vu}=5$', fontsize=5.6, rotation=90, va='center')
a.text(4.8, -0.15, r'$b_u=10$, $b_v=12$, $a_u=a_v=0$; depot deadline nonbinding', fontsize=6.0, ha='center')

b = fig.add_subplot(gs[1]); b.axis('off'); b.set_xlim(0, 10); b.set_ylim(-0.6, 6)
b.set_title('(b) One subset certificate', fontsize=7.5)
b.text(5, 4.75, r'$U=\{u,v\}$', fontsize=7.5, ha='center')
b.text(5, 3.55, r'$L_U=(7,\,5)$', fontsize=10, ha='center', color='#1f77b4',
       bbox=dict(boxstyle='round,pad=0.35', fc='white', ec='#1f77b4', lw=0.9))
b.text(5, 2.35, r'$L_U(u)=\min(10,\,12-5)=7$', fontsize=6, ha='center', color='0.3')
b.text(5, 1.75, r'$L_U(v)=\min(12,\,10-5)=5$', fontsize=6, ha='center', color='0.3')
b.text(5, 0.75, r'subset infeasible iff $\pi_u>7$ and $\pi_v>5$', fontsize=6.2, ha='center')
b.text(5, -0.15, 'one summary, reusable across states', fontsize=6.0, ha='center', style='italic')

c = fig.add_subplot(gs[2]); c.set_title('(c) Position-free queries', fontsize=7.5)
c.add_patch(Rectangle((7, 5), 6, 7, color='#1f77b4', alpha=0.16, lw=0))
c.axvline(7, color='#1f77b4', lw=0.8, ls='--'); c.axhline(5, color='#1f77b4', lw=0.8, ls='--')
c.text(7.15, 2.35, r'$L_U(u)=7$', fontsize=5.6, color='#1f77b4'); c.text(11.0, 4.45, r'$L_U(v)=5$', fontsize=5.6, color='#1f77b4', ha='center')
c.text(10.4, 11.0, r'pruned by $U$', fontsize=6, color='#1f77b4', ha='center')
for name, (xy, t, d, col) in S.items():
    pu, pv = t + d['u'], t + d['v']; c.scatter(pu, pv, s=24, color=col, zorder=3)
    lab = f'${name}$ ({pu},{pv})' + ('\nnot pruned' if name == 'r' else '')
    c.text(pu - 0.3 if name == 'r' else pu + 0.25, pv if name == 'r' else pv + 0.2, lab, fontsize=5.8, color=col, ha='right' if name == 'r' else 'left', va='bottom' if name != 'r' else 'center')
c.set_xlim(3, 12.5); c.set_ylim(2, 12); c.set_xlabel(r'$\pi_u$', fontsize=7, labelpad=1); c.set_ylabel(r'$\pi_v$', fontsize=7, labelpad=1)
c.tick_params(labelsize=5.5)
fig.savefig(f'{out}/fig1_concept.pdf', bbox_inches='tight', pad_inches=0.02); plt.close(fig)

# ---------------- Figure 2: cumulative proofs over time ----------------
R = [json.loads(l) for l in open(main_res)]
by = collections.defaultdict(dict)
for r in R: by[r['instance']][r['variant']] = r
meth = [('base', 'Base', '#7f7f7f', ':'), ('cp', 'CP', '#ff7f0e', '--'), ('cp_simpl', r'CP$_{\rm simp}$', '#d62728', '-.'), ('learn_s3', r'Static$_3$', '#2ca02c', (0,(5,1))), ('learn_s4', r'Static$_4$', '#9467bd', (0,(1,1))), ('learn_v4', 'Online', '#1f77b4', '-')]
fig, axs = plt.subplots(1, 2, figsize=(3.4, 1.5))
for ax, kind, title in [(axs[0], 'infeasible', '(a) infeasibility proofs'), (axs[1], 'optimal', '(b) optimality proofs')]:
    for v, lab, col, ls in meth:
        ts = sorted(d[v]['time'] for d in by.values() if v in d and d[v].get(kind))
        x = np.concatenate([[1e-3], ts, [300]]); y = np.concatenate([[0], np.arange(1, len(ts) + 1), [len(ts)]])
        ax.step(x, y, where='post', color=col, ls=ls, lw=1.1, label=lab)
    ax.set_xscale('log'); ax.set_xlim(1e-3, 300); ax.set_title(title, fontsize=7); ax.set_xlabel('time (s)', fontsize=6.5); ax.tick_params(labelsize=5.5)
    ax.grid(alpha=0.25, lw=0.4)
axs[0].set_ylabel('instances', fontsize=6.5); axs[1].legend(fontsize=5.3, frameon=False, loc='upper left')
fig.tight_layout(pad=0.3); fig.savefig(f'{out}/fig2_cumulative.pdf'); plt.close(fig)

# ---------------- Figure 3: reuse across rounds and depths ----------------
A = [json.loads(l) for l in open(abl_res)]
shares, D = [], collections.Counter()
for r in A:
    if r['variant'] != 'learn_v5' or 'trace' not in r: continue
    c = collections.Counter()
    for lr, ur, k in r['trace']['round']:
        c['tot'] += k; c['same'] += k * (ur == lr); c['prev'] += k * (ur == lr + 1); c['older'] += k * (ur > lr + 1)
    for ld, ud, k in r['trace']['depth']: D[(ld, ud)] += k
    if c['tot'] > 0: shares.append([c['same'] / c['tot'], c['prev'] / c['tot'], c['older'] / c['tot']])
P = np.array(shares) * 100
fig, (x1, x2) = plt.subplots(1, 2, figsize=(3.4, 1.55), gridspec_kw={'width_ratios': [1, 1.15]})
bp = x1.boxplot(P, widths=0.55, showfliers=False, patch_artist=True, medianprops=dict(color='k', lw=0.9))
for patch, col in zip(bp['boxes'], ['#c7c7c7', '#aec7e8', '#1f77b4']): patch.set_facecolor(col); patch.set_linewidth(0.6)
x1.set_xticks([1, 2, 3]); x1.set_xticklabels(['same\nround', 'previous\nround', 'older\nrounds'], fontsize=5.8)
x1.set_ylabel('% of an instance\'s\ncertificate prunes', fontsize=6.2); x1.set_title('(a) round of learning', fontsize=7); x1.tick_params(labelsize=5.5)
md = max(max(k) for k in D) + 1; M = np.zeros((md, md))
for (l, u), k in D.items(): M[l, u] = k
M = M[1:, 1:]; rows = M.sum(1, keepdims=True); Mn = np.where(rows > 0, M / np.maximum(rows, 1), np.nan)
im = x2.imshow(np.where(Mn > 0, Mn, np.nan), origin='lower', cmap='viridis', norm=LogNorm(vmin=1e-4, vmax=1), aspect='auto',
               extent=[0.5, M.shape[1] + 0.5, 0.5, M.shape[0] + 0.5])
x2.plot([0.5, M.shape[0] + 0.5], [0.5, M.shape[0] + 0.5], 'w--', lw=0.7)
x2.set_xlabel('depth of pruned state', fontsize=6.2); x2.set_ylabel('depth where learned', fontsize=6.2); x2.set_title('(b) depth (row-normalized)', fontsize=7)
x2.tick_params(labelsize=5.5); cb = fig.colorbar(im, ax=x2, fraction=0.06, pad=0.03); cb.ax.tick_params(labelsize=5)
fig.tight_layout(pad=0.3); fig.savefig(f'{out}/fig3_reuse.pdf'); plt.close(fig)
print('figures written; per-instance medians same/prev/older:', np.median(P, 0).round(1))

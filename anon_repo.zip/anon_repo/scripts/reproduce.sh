#!/bin/bash
# Reproduce the experiments of the paper.  usage:  bash scripts/reproduce.sh BLOCK [BLOCK ...]
# Run each timed block alone on an otherwise idle machine. Results are appended to results/*.jsonl
# (runs already present are skipped, so every block can be resumed).
#
# Environment (see README):
#   RS_HS     directory with the unpacked Rifki-Solnon "high-scale" instances n=31_HS and n=21_HS
#   RS_GIT    clone of the Rifki-Solnon repository (phase-transition-tsptw, contains ins/random/n=*.zip)
#   CP        Marijnissen et al.'s TSPTW binary (tsptw_rpid), built with tools/build_cp.sh
#   WB        Marijnissen et al.'s WTTW binary (wttw_rpid)
#   WTTW_BENCH  their WTTW benchmark directory (Results/wttw/benchmarks)
#   GD        directory with the 130 classical Gendreau/Dumas instances in RPID format
#   J=10 (parallel runs)  PIN=1 (pin each run to its own physical core)
set -u
J=${J:-10}; PINOPT=${PIN:+--pin}
B=target/release/lu_rpid; W=target/release/wttw; O=results
mkdir -p $O data
RUN="python3 tools/run_all.py"; EXT="python3 tools/run_external.py"
cp_runs () {  # $1 = instance dir, $2 = result file, $3 = time limit
  $EXT $1 $2 --name cp       --time-limit $3 --jobs $J $PINOPT --cmd "$CP {inst} --time-limit {tl} --simplification-level none --constraint-propagation --no-caching --history /dev/null"
  $EXT $1 $2 --name cp_simpl --time-limit $3 --jobs $J $PINOPT --cmd "$CP {inst} --time-limit {tl} --constraint-propagation --no-caching --history /dev/null"
}
st_runs () {  # static certificates: $1 = instance dir, $2 = result file, $3 = time limit, $4 = orders
  for k in ${4:-3 4}; do $RUN $B $1 $2 --variants learn --tag _s$k --extra="--static $k --no-learn" --time-limit $3 --jobs $J $PINOPT; done
}
cargo build --release --offline 2>&1 | tail -1
for blk in "$@"; do case $blk in
  data)        # instance sets used below
    python3 tools/select_rs.py $RS_HS data/rs31 --set tight   --n 31        # 540, main set (Tables 1-2, Figure 2)
    python3 tools/select_rs.py $RS_HS data/rs31_general --set general --n 31 # 135
    python3 tools/select_rs.py $RS_HS data/rs21 --set tight   --n 21        # 540
    python3 tools/make_seeds.py data/rs31 data/abl31 1 5                     # 210, ablation set (beta >= 0.4, seeds 1-5)
    python3 tools/make_subset.py data/rs31 data/sub36                        # 36, fixed subset for 1800 s
    g="--alphas 1.0,1.1,1.2,1.3,1.4,1.5 --betas 0.3,0.35,0.4,0.45,0.5 --seeds 1-5"
    for n in 31 41 51; do python3 tools/prep_rs.py "$RS_GIT/ins/random/n=$n.zip" data/scale$n $g; done ;;
  main)        # Table 1 (300 s rows), Figure 2, preprocessing check
    $RUN $B data/rs31 $O/res_n31.jsonl --variants base --time-limit 300 --jobs $J $PINOPT --history-dir $O/hist_n31
    $RUN $B data/rs31 $O/res_n31.jsonl --variants learn --tag _v4 --time-limit 300 --jobs $J $PINOPT --history-dir $O/hist_n31
    st_runs data/rs31 $O/res_n31.jsonl 300
    cp_runs data/rs31 $O/res_n31.jsonl 300
    # their binary with simplification and without propagation (preprocessing check in the setup)
    $EXT data/rs31 $O/res_n31.jsonl --name rpid_simpl --time-limit 300 --jobs $J $PINOPT --cmd "$CP {inst} --time-limit {tl} --no-caching --history /dev/null"
    V=base,cp,cp_simpl,learn_s3,learn_s4,learn_v4
    python3 tools/agg_split.py $O/res_n31.jsonl $V --curves $O/curves_n31.csv > $O/agg_n31.txt
    python3 tools/summarize.py $O/res_n31.jsonl $V,rpid_simpl >> $O/agg_n31.txt ;;
  long)        # 1800 s rows of Table 1
    $RUN $B data/sub36 $O/res_sub36_1800.jsonl --variants base,learn --time-limit 1800 --jobs $J $PINOPT
    st_runs data/sub36 $O/res_sub36_1800.jsonl 1800
    cp_runs data/sub36 $O/res_sub36_1800.jsonl 1800
    python3 tools/summarize.py $O/res_sub36_1800.jsonl base,cp,cp_simpl,learn_s3,learn_s4,learn > $O/agg_sub36_1800.txt ;;
  ablation)    # Table 2 (knowledge representations and static orders)
    A=$O/res_abl31.jsonl
    $RUN $B data/abl31 $A --variants base --time-limit 300 --jobs $J $PINOPT
    $RUN $B data/abl31 $A --variants learn --tag _v5 --time-limit 300 --jobs $J $PINOPT
    $RUN $B data/abl31 $A --variants learn --tag _dead   --extra="--cert-mode dead"   --time-limit 300 --jobs $J $PINOPT
    $RUN $B data/abl31 $A --variants learn --tag _local  --extra="--cert-mode local"  --time-limit 300 --jobs $J $PINOPT
    $RUN $B data/abl31 $A --variants learn --tag _locset --extra="--cert-mode locset" --time-limit 300 --jobs $J $PINOPT
    $RUN $B data/abl31 $A --variants learn --tag _clear  --extra="--clear-each-round" --time-limit 300 --jobs $J $PINOPT
    $RUN $B data/abl31 $A --variants learn --tag _locb       --extra="--cert-mode locbound"        --time-limit 300 --jobs $J $PINOPT
    $RUN $B data/abl31 $A --variants learn --tag _locb_nocap --extra="--cert-mode locbound --cap 0" --time-limit 300 --jobs $J $PINOPT
    st_runs data/abl31 $A 300 "2 3 4 5"
    for k in 3 4; do $RUN $B data/abl31 $A --variants learn --tag _s${k}l --extra="--static $k" --time-limit 300 --jobs $J $PINOPT; done   # static + online
    python3 tools/summarize.py $A base,learn_dead,learn_local,learn_locset,learn_clear,learn_v5 > $O/agg_abl31.txt
    python3 tools/summarize.py $A learn_s2,learn_s3,learn_s4,learn_s5,learn_s3l,learn_s4l,learn_v5 >> $O/agg_abl31.txt
    python3 tools/complement.py $A >> $O/agg_abl31.txt
    python3 tools/agg_split.py $A >> $O/agg_abl31.txt
    python3 tools/trace_summary.py $A learn_v5 >> $O/agg_abl31.txt ;;
  locstats)    # cross-location share (counts only; the run times of these runs are not used)
    $RUN $B data/abl31 $O/res_locstats31.jsonl --variants learn --tag _locstats2 --extra="--loc-stats" --time-limit 300 --jobs $J $PINOPT
    python3 tools/loc_summary.py $O/res_locstats31.jsonl learn_locstats2 > $O/agg_locstats31.txt ;;
  astar)       # A* host
    python3 tools/check_astar.py $B data/rs21 40 60 > $O/check_astar.txt
    $RUN $B data/abl31 $O/res_abl31.jsonl --variants base,learn --tag _astar --astar --time-limit 300 --jobs $J $PINOPT
    $RUN $B data/abl31 $O/res_abl31.jsonl --variants learn --tag _astar_locset --astar --extra="--cert-mode locset" --time-limit 300 --jobs $J $PINOPT
    python3 tools/summarize.py $O/res_abl31.jsonl base_astar,learn_astar_locset,learn_astar > $O/agg_astar.txt ;;
  params)      # K and cap
    for k in 3 6 14; do $RUN $B data/abl31 $O/res_abl31.jsonl --variants learn --tag _k$k --extra="--kmax $k" --time-limit 300 --jobs $J $PINOPT; done
    for c in 500 8000; do $RUN $B data/abl31 $O/res_abl31.jsonl --variants learn --tag _cap$c --extra="--cap $c" --time-limit 300 --jobs $J $PINOPT; done
    $RUN $B data/abl31 $O/res_abl31.jsonl --variants learn --tag _nocap --extra="--cap 0" --time-limit 300 --jobs $J $PINOPT
    python3 tools/summarize.py $O/res_abl31.jsonl learn_k3,learn_k6,learn_v5,learn_k14 learn_cap500,learn_v5,learn_cap8000,learn_nocap > $O/agg_params.txt ;;
  scale)       # Table 3 (31, 41, 51 nodes)
    for n in 31 41 51; do
      $RUN $B data/scale$n $O/res_scale$n.jsonl --variants base,learn --time-limit 300 --jobs $J $PINOPT
      st_runs data/scale$n $O/res_scale$n.jsonl 300
      cp_runs data/scale$n $O/res_scale$n.jsonl 300
      python3 tools/summarize.py $O/res_scale$n.jsonl base,cp,cp_simpl,learn_s3,learn_s4,learn > $O/agg_scale$n.txt
      python3 tools/complement.py $O/res_scale$n.jsonl >> $O/agg_scale$n.txt
      python3 tools/open_count.py $O/res_scale$n.jsonl >> $O/agg_scale$n.txt
    done ;;
  cost)        # Table 4 (cost control) and the n=21 row of Table 5
    C=$O/res_n21.jsonl
    $RUN $B data/rs21 $C --variants base --time-limit 300 --jobs $J $PINOPT
    $RUN $B data/rs21 $C --variants learn --tag _v4 --time-limit 300 --jobs $J $PINOPT
    $RUN $B data/rs21 $C --variants learn --tag _nogate_nocap --extra="--no-gate --cap 0" --time-limit 300 --jobs $J $PINOPT
    $RUN $B data/rs21 $C --variants learn --tag _caponly  --extra="--no-gate" --time-limit 300 --jobs $J $PINOPT
    $RUN $B data/rs21 $C --variants learn --tag _gateonly --extra="--cap 0"   --time-limit 300 --jobs $J $PINOPT
    python3 tools/agg_split.py $C base,learn_nogate_nocap,learn_caponly,learn_gateonly,learn_v4 > $O/agg_n21.txt ;;
  other)       # Table 5 (general n=31, Gendreau/Dumas; n=21 is in block cost)
    for s in rs31_general; do
      $RUN $B data/$s $O/res_$s.jsonl --variants base,learn --time-limit 300 --jobs $J $PINOPT
      cp_runs data/$s $O/res_$s.jsonl 300
      python3 tools/agg_split.py $O/res_$s.jsonl base,cp,cp_simpl,learn > $O/agg_$s.txt
    done
    $RUN $B $GD $O/res_gde.jsonl --variants base,learn --time-limit 300 --jobs $J $PINOPT
    $EXT $GD $O/res_gde.jsonl --name cp --time-limit 300 --jobs $J $PINOPT --cmd "$CP {inst} --time-limit {tl} --simplification-level none --constraint-propagation --no-caching --history /dev/null"
    python3 tools/agg.py $O/res_gde.jsonl base,cp,learn > $O/agg_gde.txt ;;
  wttw)        # single-machine scheduling
    python3 tools/wttw_convert.py $WTTW_BENCH data/wttw_ours data/wttw_theirs --sets General,Extended --per-combo 3
    $RUN $W data/wttw_ours $O/res_wttw.jsonl --variants base,learn --time-limit 300 --jobs $J $PINOPT
    $EXT data/wttw_theirs $O/res_wttw.jsonl --name rpid_ref --validator wttw --time-limit 300 --jobs $J $PINOPT --cmd "$WB {inst} --time-limit {tl} --history /dev/null"
    $EXT data/wttw_theirs $O/res_wttw.jsonl --name cp --validator wttw --time-limit 300 --jobs $J $PINOPT --cmd "$WB {inst} --time-limit {tl} --constraint-propagation --no-caching --history /dev/null"
    python3 tools/agg_split.py $O/res_wttw.jsonl base,learn,rpid_ref,cp > $O/agg_wttw.txt ;;
  cpcache)     # CP with the state cache of their binary (default of the binary; their reported experiments disable it)
    $EXT data/rs31 $O/res_cpcache_n31.jsonl --name cp_cache --time-limit 300 --jobs $J $PINOPT --cmd "$CP {inst} --time-limit {tl} --simplification-level none --constraint-propagation --limit-in-mb 12000 --history /dev/null"
    $EXT data/rs31 $O/res_cpcache_n31.jsonl --name cp_simpl_cache --time-limit 300 --jobs $J $PINOPT --cmd "$CP {inst} --time-limit {tl} --constraint-propagation --limit-in-mb 12000 --history /dev/null"
    python3 tools/summarize.py $O/res_cpcache_n31.jsonl cp_cache,cp_simpl_cache > $O/agg_cpcache_n31.txt
    $EXT data/wttw_theirs $O/res_wttw.jsonl --name cp_cache --validator wttw --time-limit 300 --jobs $J $PINOPT --cmd "$WB {inst} --time-limit {tl} --constraint-propagation --limit-in-mb 12000 --history /dev/null"
    python3 tools/agg_split.py $O/res_wttw.jsonl base,learn,cp,cp_cache > $O/agg_wttw_cache.txt ;;
  audit)       # independent audit of infeasibility proofs found only by certificate variants
    python3 tools/audit_proofs.py $O/res_n31.jsonl   data/rs31  $B --time-limit 300  --jobs $J --out $O/audit_n31.jsonl
    python3 tools/audit_proofs.py $O/res_rs31_general.jsonl data/rs31_general $B --time-limit 300 --jobs $J --out $O/audit_general.jsonl
    python3 tools/audit_proofs.py $O/res_abl31.jsonl data/abl31 $B --time-limit 300  --jobs $J --out $O/audit_abl31.jsonl
    python3 tools/audit_proofs.py $O/res_sub36_1800.jsonl data/sub36 $B --time-limit 1800 --jobs $J --out $O/audit_sub36.jsonl ;;
  figures)
    python3 scripts/make_figs.py $O/res_n31.jsonl $O/res_abl31.jsonl $O/figs ;;
  test)        # correctness against brute force on small instances (not timed)
    $RUN $B tests/tsptw_small $O/test_tsptw.jsonl --variants base,learn,pair,pair_learn --time-limit 60 --jobs $J
    for x in "_s3:--static 3 --no-learn" "_s3l:--static 3" "_locset:--cert-mode locset" "_local:--cert-mode local" "_dead:--cert-mode dead"; do
      $RUN $B tests/tsptw_small $O/test_tsptw.jsonl --variants learn --tag ${x%%:*} --extra="${x#*:}" --time-limit 60 --jobs $J
    done
    $RUN $B tests/tsptw_small $O/test_tsptw.jsonl --variants base,learn --tag _astar --astar --time-limit 60 --jobs $J
    python3 tools/check_ref.py $O/test_tsptw.jsonl tests/tsptw_small_ref.json
    $RUN $W tests/wttw_small $O/test_wttw.jsonl --variants base,learn --time-limit 60 --jobs $J
    python3 tools/check_ref.py $O/test_wttw.jsonl tests/wttw_small_ref.json ;;
  *) echo "unknown block $blk"; exit 1 ;;
esac; done

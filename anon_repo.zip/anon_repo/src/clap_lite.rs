//! Minimal argument parser (no external crates).
pub struct Args {
    pub input: String,
    pub variant: String,
    pub time_limit: f64,
    pub kmax: usize,
    pub astar: bool,
    pub history: String,
    pub no_index: bool,
    pub cap: usize,
    pub no_gate: bool,
    pub loc_stats: bool,
    pub static_k: usize,
    pub no_learn: bool,
    pub clear_each_round: bool,
    pub cert_mode: String,
    pub dump_certs: Option<String>,
    pub no_active_rule: bool,
}
const HELP: &str = "usage: lu_rpid INSTANCE [options]   (wttw INSTANCE [options] for the scheduling model)
  --variant V          base | learn (certificates, the method) | pair | pair_learn       [base]
  --time-limit S       time limit in seconds                                             [60]
  --astar              use A* instead of CABS as the host search
  --kmax K             largest subset tried during extraction                            [10]
  --cap C              maximum number of stored certificates, 0 = no cap                 [2000]
  --no-gate            disable the bound gate
  --no-index           disable the anchor index
  --clear-each-round   clear the certificate store at the start of every CABS round
  --cert-mode M        lu (method) | locset (same store, queried only at extraction locations)
                       | locbound (one entry per subset and location) | local (location/time-bound nogood)
                       | dead (dead-state memo)                                          [lu]
  --static K           precompute the certificates of all customer subsets of size 2..K (static baseline)
  --no-learn           do not learn certificates at dead ends (use with --static)
  --loc-stats          count cross-location prunes (adds a counterfactual scan; do not use its run times)
  --dump-certs FILE    write a proof log (all certificates, sample of prune events) for tools/verify_certs.py
  --history FILE       write the anytime history (time, bounds, expansions) as CSV
  --no-active-rule     (wttw only) disable the active-schedule rule";
impl Args {
    pub fn parse() -> Self {
        let mut a = Args { input: String::new(), variant: "base".into(), time_limit: 60.0, kmax: 10, astar: false, history: "/dev/null".into(), no_index: false, cap: 2000, no_gate: false, loc_stats: false, static_k: 0, no_learn: false, clear_each_round: false, cert_mode: "lu".into(), dump_certs: None, no_active_rule: false };
        let v: Vec<String> = std::env::args().skip(1).collect();
        let mut i = 0;
        while i < v.len() {
            match v[i].as_str() {
                "--help" | "-h" => { println!("{HELP}"); std::process::exit(0); }
                "--variant" => { a.variant = v[i + 1].clone(); i += 1; }
                "--time-limit" => { a.time_limit = v[i + 1].parse().unwrap(); i += 1; }
                "--kmax" => { a.kmax = v[i + 1].parse().unwrap(); i += 1; }
                "--history" => { a.history = v[i + 1].clone(); i += 1; }
                "--astar" => { a.astar = true; }
                "--no-index" => { a.no_index = true; }
                "--no-gate" => { a.no_gate = true; }
                "--loc-stats" => { a.loc_stats = true; }
                "--static" => { a.static_k = v[i + 1].parse().unwrap(); i += 1; }
                "--no-learn" => { a.no_learn = true; }
                "--clear-each-round" => { a.clear_each_round = true; }
                "--no-active-rule" => { a.no_active_rule = true; }
                "--dump-certs" => { a.dump_certs = Some(v[i + 1].clone()); i += 1; }
                "--cert-mode" => { a.cert_mode = v[i + 1].clone(); i += 1; }
                "--cap" => { a.cap = v[i + 1].parse().unwrap(); i += 1; }
                s if s.starts_with("--") => { eprintln!("unknown option {s}\n{HELP}"); std::process::exit(2); }
                s => { a.input = s.to_string(); }
            }
            i += 1;
        }
        if a.input.is_empty() { eprintln!("{HELP}"); std::process::exit(2); }
        a
    }
}

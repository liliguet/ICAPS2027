//! TSPTW in RPID with cross-state subset nogood learning (L_U certificates).
//!
//! The base model is identical to the official RPID TSPTW model in didp-rust-models
//! (state = (unvisited, current, time), single-customer state constraint on c*, dominance on
//! earlier time, dual bound = max(MinTo, MinFrom)). Variants add pruning inside get_successors:
//!   base       : official model
//!   pair       : + 2-client check at every successor (proactive, per-state reasoning)
//!   learn      : + L_U certificates learned at dead states, matched at every successor
//!   pair_learn : pair + learn
//! A certificate (U, L) says: from any state whose unvisited set contains U, if the earliest
//! service start pi_x > L_x for every x in U, the state is infeasible. L is the exact latest
//! service start at x such that all of U (then the depot) can still be served, computed by a
//! backward subset DP on the metric closure F (sound: F <= every real travel time).

use clap_lite::Args;
use fixedbitset::FixedBitSet;
use rpid::prelude::*;
use rpid::{BoundMut, DpMut};
use rpid::{io, solvers, timer::Timer};
use std::cmp::{self, Ordering};
use std::time::Instant;

mod clap_lite;

const NEG: i64 = i64::MIN / 4;

#[derive(Clone)]
struct Instance {
    a: Vec<i32>,
    b: Vec<i32>,
    c: Vec<Vec<Option<i32>>>,
}

impl Instance {
    fn read(path: &str) -> Self {
        let s = std::fs::read_to_string(path).expect("cannot read instance");
        let mut it = s.split_whitespace().map(|x| x.parse::<f64>().expect("bad number"));
        let n = it.next().unwrap() as usize;
        let mut c = vec![vec![None; n]; n];
        for i in 0..n {
            for j in 0..n {
                let d = it.next().unwrap().round() as i32;
                if i != j {
                    c[i][j] = Some(d);
                }
            }
        }
        let mut a = vec![0; n];
        let mut b = vec![0; n];
        for i in 0..n {
            a[i] = it.next().unwrap().round() as i32;
            b[i] = it.next().unwrap().round() as i32;
        }
        Self { a, b, c }
    }

    fn validate(&self, tour: &[usize], cost: i32) -> bool {
        let n = self.a.len();
        if tour.len() != n - 1 {
            return false;
        }
        let (mut t, mut cur, mut total) = (self.a[0].max(0), 0usize, 0);
        let mut seen = vec![false; n];
        for &nx in tour.iter().chain(std::iter::once(&0)) {
            if seen[nx] {
                return false;
            }
            let Some(d) = self.c[cur][nx] else { return false };
            t = cmp::max(t + d, self.a[nx]);
            total += d;
            if t > self.b[nx] {
                return false;
            }
            seen[nx] = true;
            cur = nx;
        }
        total == cost
    }
}

#[derive(Clone, Copy, PartialEq, Debug)]
enum Variant {
    Base,
    Pair,
    Learn,
    PairLearn,
}

struct Cert {
    mask: FixedBitSet,
    nodes: Vec<usize>,
    lat: Vec<i64>,
    anchor: usize,
    la: i64,
    hits: u64,
    learn_round: usize,
    learn_depth: usize,
    uid: usize,
    loc: usize,
    locs: FixedBitSet, // every location at which this U was extracted (loc-stats only)
    fixed: bool,       // precomputed static certificate (never evicted)
    used: bool,        // has pruned at least one state
}

/// Proof log (for independent verification): every certificate ever stored, with the state where it
/// was learned, and a sample of prune events (state + certificate uid).
#[derive(Default)]
struct ProofLog {
    path: Option<String>,
    certs: Vec<(Vec<usize>, Vec<i64>, usize, i32)>, // (U, L_U, location, time) at learning
    events: Vec<(usize, usize, i32, Vec<usize>)>,     // (uid, location, time, unvisited)
    seen_events: u64,
    rng: u64,
}

/// Position-bound nogood (ablation): from position `pos` at any time >= t0, the customer set `mask`
/// (subset of the unvisited set) cannot be completed.
struct LocalCert {
    mask: FixedBitSet,
    t0: i32,
    learn_round: usize,
    learn_depth: usize,
}

#[derive(Clone, Copy, PartialEq, Debug)]
enum CertMode {
    Lu,    // L_U summaries, position- and time-independent (the method)
    Local, // minimised subset U, but bound to the position and time where it was learned
    Dead,  // the whole dead state (U = all unvisited), bound to position and time
    LocSet,   // one entry per U (same store and cap as Lu), queried only at locations where U was extracted
    LocBound, // exactly the L_U certificate, but queried only at the location where it was learned
}

const MAXR: usize = 40;

#[derive(Default, Debug)]
struct Stats {
    expanded: u64,
    pruned_single: u64,
    pruned_pair: u64,
    pruned_cert: u64,
    dead_states: u64,
    certs: u64,
    cert_size_hist: [u64; 17],
    extract_failed: u64,
    evictions: u64,
    skipped_by_bound: u64,
    t_pair: f64,
    t_cert: f64,
    t_extract: f64,
    loc_same: u64,      // firing certificate learned at the pruned state's location
    loc_other: u64,     // firing certificate learned elsewhere, but a same-location certificate also fires
    dup_learned: u64,
    static_certs: u64,
    static_used: u64,
    t_static: f64,
    loc_other_only: u64, // no certificate learned at this location fires: prune impossible for a location-bound store
}

struct Tsptw {
    ins: Instance,
    c_star: Vec<Vec<Option<i32>>>, // official: shortest paths not entering the depot
    f: Vec<Vec<i64>>,              // full metric closure (for certificates; sound relaxation)
    min_to: Vec<i32>,
    min_from: Vec<i32>,
    variant: Variant,
    kmax: usize,
    certs: Vec<Cert>,
    index: Vec<Vec<(i64, usize)>>, // per anchor customer: (L_anchor, cert id), sorted ascending
    use_index: bool,
    loc_stats: bool,
    static_k: usize,   // precompute all subsets of size 2..=static_k at the first expansion (0 = off)
    static_done: bool,
    no_learn: bool,    // do not learn at dead ends
    n_fixed: usize,
    cap: usize,
    plog: ProofLog,
    mode: CertMode,
    clear_each_round: bool,
    round: usize,
    local: Vec<Vec<LocalCert>>,
    tr_depth: Vec<u64>, // [learn_depth * n + use_depth]
    tr_round: Vec<u64>, // [learn_round * MAXR + use_round]
    incumbent: i32,
    bound_gate: bool,
    seen: rustc_hash_lite::Set,
    st: Stats,
}

mod rustc_hash_lite {
    pub type Set = std::collections::HashSet<Vec<usize>>;
}

fn floyd(c: &[Vec<Option<i32>>]) -> Vec<Vec<Option<i32>>> {
    let n = c.len();
    let mut d: Vec<Vec<Option<i32>>> = c.to_vec();
    for i in 0..n {
        d[i][i] = Some(0);
    }
    for k in 0..n {
        for i in 0..n {
            let Some(dik) = d[i][k] else { continue };
            for j in 0..n {
                if let Some(dkj) = d[k][j] {
                    let v = dik + dkj;
                    if d[i][j].map_or(true, |x| v < x) {
                        d[i][j] = Some(v);
                    }
                }
            }
        }
    }
    d
}

impl Tsptw {
    fn new(ins: Instance, variant: Variant, kmax: usize) -> Self {
        let n = ins.a.len();
        let mut c0 = ins.c.clone();
        c0.iter_mut().for_each(|row| row[0] = None);
        let c_star = floyd(&c0);
        let full = floyd(&ins.c);
        let big = 1i64 << 40;
        let f = full
            .iter()
            .map(|r| r.iter().map(|x| x.map_or(big, |v| v as i64)).collect())
            .collect();
        let min_to = (0..n)
            .map(|j| (0..n).filter_map(|i| ins.c[i][j]).min().unwrap_or(0))
            .collect();
        let min_from = (0..n)
            .map(|i| ins.c[i].iter().filter_map(|&x| x).min().unwrap_or(0))
            .collect();
        Self {
            ins,
            c_star,
            f,
            min_to,
            min_from,
            variant,
            kmax,
            certs: vec![],
            index: vec![vec![]; n],
            use_index: true,
            loc_stats: false,
            static_k: 0,
            static_done: false,
            no_learn: false,
            n_fixed: 0,
            cap: 0,
            plog: ProofLog::default(),
            mode: CertMode::Lu,
            clear_each_round: false,
            round: 0,
            local: (0..n).map(|_| Vec::new()).collect(),
            tr_depth: vec![0; n * n],
            tr_round: vec![0; MAXR * MAXR],
            incumbent: i32::MAX,
            bound_gate: true,
            seen: Default::default(),
            st: Stats::default(),
        }
    }

    fn dual(&self, s: &TsptwState) -> i32 {
        let to = s.unvisited.ones().map(|i| self.min_to[i]).sum::<i32>() + self.min_to[0];
        let from = self.min_from[s.current] + s.unvisited.ones().map(|i| self.min_from[i]).sum::<i32>();
        cmp::max(to, from)
    }

    fn single_ok(&self, s: &TsptwState) -> bool {
        s.unvisited.ones().all(|u| match self.c_star[s.current][u] {
            Some(d) => s.time + d <= self.ins.b[u],
            None => false,
        })
    }

    #[inline]
    fn pi(&self, cur: usize, t: i32, x: usize) -> i64 {
        cmp::max(t as i64 + self.f[cur][x], self.ins.a[x] as i64)
    }

    fn pair_ok(&self, s: &TsptwState) -> bool {
        let u: Vec<usize> = s.unvisited.ones().collect();
        let tau: Vec<i64> = u.iter().map(|&x| self.pi(s.current, s.time, x)).collect();
        for p in 0..u.len() {
            for q in (p + 1)..u.len() {
                let (x, y) = (u[p], u[q]);
                let xy = cmp::max(tau[p] + self.f[x][y], self.ins.a[y] as i64) <= self.ins.b[y] as i64;
                let yx = cmp::max(tau[q] + self.f[y][x], self.ins.a[x] as i64) <= self.ins.b[x] as i64;
                if !xy && !yx {
                    return false;
                }
            }
        }
        true
    }

    /// Latest service start L_U(x) (x first), all of U then the depot; NEG if impossible.
    fn latest_start(&self, u: &[usize]) -> Vec<i64> {
        let m = u.len();
        let full = (1usize << m) - 1;
        let mut lat = vec![NEG; (1 << m) * m];
        let (ins, f) = (&self.ins, &self.f);
        for i in 0..m {
            let x = u[i];
            let v = cmp::min(ins.b[x] as i64, ins.b[0] as i64 - f[x][0]);
            lat[(1 << i) * m + i] = if v >= ins.a[x] as i64 { v } else { NEG };
        }
        // iterate subsets in increasing popcount order (numeric order suffices: rest < S)
        for s in 1..=full {
            if s.count_ones() < 2 {
                continue;
            }
            for i in 0..m {
                if s >> i & 1 == 0 {
                    continue;
                }
                let rest = s & !(1 << i);
                let x = u[i];
                let mut best = NEG;
                for j in 0..m {
                    if rest >> j & 1 == 1 {
                        let l = lat[rest * m + j];
                        if l > NEG {
                            best = cmp::max(best, l - f[x][u[j]]);
                        }
                    }
                }
                let v = cmp::min(ins.b[x] as i64, best);
                lat[s * m + i] = if best > NEG && v >= ins.a[x] as i64 { v } else { NEG };
            }
        }
        (0..m).map(|i| lat[full * m + i]).collect()
    }

    fn infeasible_from(&self, cur: usize, t: i32, u: &[usize]) -> Option<Vec<i64>> {
        let l = self.latest_start(u);
        if u.iter().zip(&l).all(|(&x, &lx)| self.pi(cur, t, x) > lx) {
            Some(l)
        } else {
            None
        }
    }

    fn depth(&self, s: &TsptwState) -> usize {
        self.ins.a.len() - 1 - s.unvisited.count_ones(..)
    }

    fn push_local(&mut self, s: &TsptwState, mask: FixedBitSet, size: usize) {
        let (lr, ld) = (cmp::min(self.round, MAXR - 1), self.depth(s));
        let lst = &mut self.local[s.current];
        lst.push(LocalCert { mask, t0: s.time, learn_round: lr, learn_depth: ld });
        if self.cap > 0 && lst.len() > self.cap {
            let half = lst.len() / 2;
            lst.drain(..half); // drop the oldest half
            self.st.evictions += 1;
        }
        self.st.certs += 1;
        self.st.cert_size_hist[cmp::min(size, 16)] += 1;
    }

    fn learn_at(&mut self, s: &TsptwState) {
        let t0 = Instant::now();
        if self.mode == CertMode::Dead {
            let size = s.unvisited.count_ones(..);
            self.push_local(s, s.unvisited.clone(), size);
            self.st.t_extract += t0.elapsed().as_secs_f64();
            return;
        }
        let mut order: Vec<usize> = s.unvisited.ones().collect();
        if order.len() < 2 {
            return;
        }
        order.sort_by_key(|&x| self.ins.b[x]);
        let mut found: Option<Vec<usize>> = None;
        for k in 2..=cmp::min(self.kmax, order.len()) {
            if self.infeasible_from(s.current, s.time, &order[..k]).is_some() {
                found = Some(order[..k].to_vec());
                break;
            }
        }
        if let Some(mut u) = found {
            let mut i = 0;
            while i < u.len() && u.len() > 2 {
                let mut trial = u.clone();
                trial.remove(i);
                if self.infeasible_from(s.current, s.time, &trial).is_some() {
                    u = trial;
                } else {
                    i += 1;
                }
            }
            let lat = self.infeasible_from(s.current, s.time, &u).expect("minimised set must stay infeasible");
            if self.mode == CertMode::Local {
                let mut mask = FixedBitSet::with_capacity(self.ins.a.len());
                u.iter().for_each(|&x| mask.insert(x));
                let size = u.len();
                self.push_local(s, mask, size);
                self.st.t_extract += t0.elapsed().as_secs_f64();
                return;
            }
            let mut key = u.clone();
            key.sort();
            if self.mode == CertMode::LocBound { key.push(usize::MAX - s.current); } // one entry per (U, location)
            if self.seen.insert(key.clone()) {
                let mut mask = FixedBitSet::with_capacity(self.ins.a.len());
                u.iter().for_each(|&x| mask.insert(x));
                self.st.cert_size_hist[cmp::min(u.len(), 16)] += 1;
                // anchor = element with the largest latest start (the hardest condition to meet)
                let (ai, _) = lat.iter().enumerate().max_by_key(|(_, l)| **l).unwrap();
                let (anchor, la) = (u[ai], lat[ai]);
                let id = self.certs.len();
                let g = &mut self.index[anchor];
                let pos = g.partition_point(|&(l, _)| l <= la);
                g.insert(pos, (la, id));
                let (lr, ld) = (cmp::min(self.round, MAXR - 1), self.depth(s));
                let uid = self.plog.certs.len();
                if self.plog.path.is_some() {
                    self.plog.certs.push((u.clone(), lat.clone(), s.current, s.time));
                }
                self.certs.push(Cert { mask, nodes: u, lat, anchor, la, hits: 0, learn_round: lr, learn_depth: ld, uid, loc: s.current, locs: { let mut b = FixedBitSet::with_capacity(self.ins.a.len()); b.insert(s.current); b }, fixed: false, used: false });
                self.st.certs += 1;
                if self.cap > 0 && self.certs.len() - self.n_fixed > self.cap {
                    self.evict();
                }
            } else if (self.loc_stats && self.mode == CertMode::Lu) || self.mode == CertMode::LocSet {
                // same U extracted again at another dead end: remember this location as a learning location too
                self.st.dup_learned += 1;
                let cur = s.current;
                // locate the stored copy through the anchor index (same L_U, so same anchor and la)
                let (ai, _) = lat.iter().enumerate().max_by_key(|(_, l)| **l).unwrap();
                let (anchor, la) = (u[ai], lat[ai]);
                let g = &self.index[anchor];
                let lo = g.partition_point(|&(l, _)| l < la);
                let mut found = None;
                for &(l, id) in &g[lo..] {
                    if l != la { break; }
                    let mut k = self.certs[id].nodes.clone(); k.sort();
                    if k == key { found = Some(id); break; }
                }
                if let Some(id) = found { self.certs[id].locs.insert(cur); }
            }
        } else {
            self.st.extract_failed += 1;
        }
        self.st.t_extract += t0.elapsed().as_secs_f64();
    }

    /// Static baseline: precompute the certificate of every customer subset of size 2..=k (no learning needed).
    fn add_static(&mut self, k: usize) {
        let t0 = Instant::now();
        let n = self.ins.a.len();
        let cust: Vec<usize> = (1..n).collect();
        let mut stack: Vec<(usize, Vec<usize>)> = vec![(0, vec![])];
        while let Some((start, u)) = stack.pop() {
            if u.len() >= 2 {
                let lat = self.latest_start(&u);
                let mut mask = FixedBitSet::with_capacity(n);
                u.iter().for_each(|&x| mask.insert(x));
                let mut key = u.clone(); key.sort();
                self.seen.insert(key);
                let (ai, _) = lat.iter().enumerate().max_by_key(|(_, l)| **l).unwrap();
                let (anchor, la) = (u[ai], lat[ai]);
                let id = self.certs.len();
                self.index[anchor].push((la, id));
                self.certs.push(Cert { mask, nodes: u.clone(), lat, anchor, la, hits: 0, learn_round: 0, learn_depth: 0, uid: usize::MAX, loc: 0, locs: FixedBitSet::with_capacity(n), fixed: true, used: false });
                self.st.static_certs += 1;
            }
            if u.len() < k {
                for i in start..cust.len() { let mut v = u.clone(); v.push(cust[i]); stack.push((i + 1, v)); }
            }
        }
        self.index.iter_mut().for_each(|g| g.sort_by_key(|&(l, _)| l));
        self.n_fixed = self.certs.len();
        self.st.t_static += t0.elapsed().as_secs_f64();
    }

    /// Keep the most useful half of the store (by hits since the last eviction) and rebuild the index.
    fn evict(&mut self) {
        let keep = self.cap / 2;
        let all = std::mem::take(&mut self.certs);
        let (mut certs, mut learned): (Vec<Cert>, Vec<Cert>) = all.into_iter().partition(|c| c.fixed);
        learned.sort_by(|a, b| b.hits.cmp(&a.hits));
        learned.truncate(keep);
        certs.extend(learned);
        certs.iter_mut().for_each(|c| c.hits /= 2);
        self.index.iter_mut().for_each(|g| g.clear());
        self.seen.clear();
        for (id, c) in certs.iter().enumerate() {
            self.index[c.anchor].push((c.la, id));
            let mut key = c.nodes.clone();
            key.sort();
            if self.mode == CertMode::LocBound { key.push(usize::MAX - c.loc); }
            self.seen.insert(key);
        }
        self.index.iter_mut().for_each(|g| g.sort_by_key(|&(l, _)| l));
        self.certs = certs;
        self.st.evictions += 1;
    }

    fn cert_violated(&mut self, s: &TsptwState) -> bool {
        let n = self.ins.a.len();
        let (ur, ud) = (cmp::min(self.round, MAXR - 1), self.depth(s));
        if matches!(self.mode, CertMode::Local | CertMode::Dead) {
            let hit = self.local[s.current]
                .iter()
                .find(|c| c.t0 <= s.time && c.mask.as_slice().iter().zip(s.unvisited.as_slice()).all(|(a, b)| a & !b == 0))
                .map(|c| (c.learn_round, c.learn_depth));
            if let Some((lr, ld)) = hit {
                self.tr_round[lr * MAXR + ur] += 1;
                self.tr_depth[ld * n + ud] += 1;
                return true;
            }
            return false;
        }
        if let Some(id) = self.find_violated(s) {
            self.certs[id].hits += 1;
            self.certs[id].used = true;
            if self.loc_stats {
                if self.certs[id].locs.contains(s.current) {
                    self.st.loc_same += 1;
                } else {
                    let same = self.certs.iter().any(|c| c.locs.contains(s.current)
                        && c.mask.as_slice().iter().zip(s.unvisited.as_slice()).all(|(a, b)| a & !b == 0)
                        && c.nodes.iter().zip(&c.lat).all(|(&x, &l)| self.pi(s.current, s.time, x) > l));
                    if same { self.st.loc_other += 1; } else { self.st.loc_other_only += 1; }
                }
            }
            if self.plog.path.is_some() {
                // reservoir sample of at most 50000 prune events
                self.plog.seen_events += 1;
                let ev = (self.certs[id].uid, s.current, s.time, s.unvisited.ones().collect::<Vec<_>>());
                if self.plog.events.len() < 50000 {
                    self.plog.events.push(ev);
                } else {
                    self.plog.rng = self.plog.rng.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
                    let k = (self.plog.rng >> 11) % self.plog.seen_events;
                    if (k as usize) < 50000 { self.plog.events[k as usize] = ev; }
                }
            }
            let (lr, ld) = (self.certs[id].learn_round, self.certs[id].learn_depth);
            self.tr_round[lr * MAXR + ur] += 1;
            self.tr_depth[ld * n + ud] += 1;
            true
        } else {
            false
        }
    }

    fn has_certs(&self) -> bool {
        if matches!(self.mode, CertMode::Lu | CertMode::LocBound | CertMode::LocSet) { !self.certs.is_empty() } else { self.local.iter().any(|l| !l.is_empty()) }
    }

    fn clear_store(&mut self) {
        self.certs.clear();
        self.index.iter_mut().for_each(|g| g.clear());
        self.seen.clear();
        self.local.iter_mut().for_each(|l| l.clear());
    }

    fn find_violated(&self, s: &TsptwState) -> Option<usize> {
        let locb = self.mode == CertMode::LocBound;
        let locset = self.mode == CertMode::LocSet;
        let full = |c: &Cert| {
            (!locb || c.loc == s.current) && (!locset || c.locs.contains(s.current)) && c.mask.as_slice().iter().zip(s.unvisited.as_slice()).all(|(a, b)| a & !b == 0)
                && c.nodes.iter().zip(&c.lat).all(|(&x, &l)| self.pi(s.current, s.time, x) > l)
        };
        if !self.use_index {
            return self.certs.iter().position(full);
        }
        // a certificate can only fire if pi_anchor > L_anchor; groups are sorted by L_anchor
        for x in s.unvisited.ones() {
            let g = &self.index[x];
            if g.is_empty() {
                continue;
            }
            let px = self.pi(s.current, s.time, x);
            for &(lx, id) in g {
                if lx >= px {
                    break;
                }
                if full(&self.certs[id]) {
                    return Some(id);
                }
            }
        }
        None
    }
}

#[derive(Clone)]
struct TsptwState {
    unvisited: FixedBitSet,
    current: usize,
    time: i32,
    g: i32, // path cost so far; not part of the DP state (key/dominance ignore it), used only to skip
            // certificate checks on successors that the solver will prune by bound anyway
}

impl DpMut for Tsptw {
    type State = TsptwState;
    type CostType = i32;
    type Label = usize;

    fn get_target(&self) -> TsptwState {
        let mut unvisited = FixedBitSet::with_capacity(self.ins.a.len());
        unvisited.insert_range(1..);
        TsptwState { unvisited, current: 0, time: self.ins.a[0].max(0), g: 0 }
    }

    fn get_successors(&mut self, state: &TsptwState, out: &mut Vec<(TsptwState, i32, usize)>) {
        self.st.expanded += 1;
        if self.static_k >= 2 && !self.static_done {
            self.static_done = true; // inside the search, so the precomputation counts towards the time limit
            self.add_static(self.static_k);
        }
        if state.current == 0 && state.unvisited.count_ones(..) == self.ins.a.len() - 1 {
            self.round += 1; // the root is re-expanded at the start of every beam-search round
            if self.clear_each_round && self.round > 1 {
                self.clear_store();
            }
        }
        let use_pair = matches!(self.variant, Variant::Pair | Variant::PairLearn);
        let use_learn = matches!(self.variant, Variant::Learn | Variant::PairLearn);
        let mut any_time_feasible = false;
        let before = out.len();
        for next in state.unvisited.ones() {
            let Some(d) = self.ins.c[state.current][next] else { continue };
            let time = cmp::max(state.time + d, self.ins.a[next]);
            if time > self.ins.b[next] {
                continue;
            }
            any_time_feasible = true;
            let mut unvisited = state.unvisited.clone();
            unvisited.remove(next);
            let succ = TsptwState { unvisited, current: next, time, g: state.g + d };
            if !self.single_ok(&succ) {
                self.st.pruned_single += 1;
                continue;
            }
            // successors that the solver will discard by bound anyway need no extra reasoning
            if self.bound_gate && self.incumbent < i32::MAX && succ.g + self.dual(&succ) >= self.incumbent {
                self.st.skipped_by_bound += 1;
                out.push((succ, d, next));
                continue;
            }
            if use_pair {
                let t0 = Instant::now();
                let ok = self.pair_ok(&succ);
                self.st.t_pair += t0.elapsed().as_secs_f64();
                if !ok {
                    self.st.pruned_pair += 1;
                    continue;
                }
            }
            if use_learn && self.has_certs() {
                let t0 = Instant::now();
                let bad = self.cert_violated(&succ);
                self.st.t_cert += t0.elapsed().as_secs_f64();
                if bad {
                    self.st.pruned_cert += 1;
                    continue;
                }
            }
            out.push((succ, d, next));
        }
        let _ = any_time_feasible;
        if out.len() == before && !state.unvisited.is_clear() {
            self.st.dead_states += 1;
            if use_learn && !self.no_learn {
                self.learn_at(state);
            }
        }
    }

    fn get_base_cost(&mut self, state: &TsptwState) -> Option<i32> {
        if state.unvisited.is_clear() {
            let r = self.ins.c[state.current][0].filter(|&d| state.time + d <= self.ins.b[0]);
            if let Some(d) = r {
                self.incumbent = cmp::min(self.incumbent, state.g + d); // a real tour: valid upper bound
            }
            r
        } else {
            None
        }
    }
}

impl Dominance for Tsptw {
    type State = TsptwState;
    type Key = (FixedBitSet, usize);
    fn get_key(&self, s: &TsptwState) -> Self::Key {
        (s.unvisited.clone(), s.current)
    }
    fn compare(&self, a: &TsptwState, b: &TsptwState) -> Option<Ordering> {
        Some(b.time.cmp(&a.time))
    }
}

impl BoundMut for Tsptw {
    type State = TsptwState;
    type CostType = i32;
    fn get_dual_bound(&mut self, s: &TsptwState) -> Option<i32> {
        Some(self.dual(s))
    }
}

fn main() {
    let timer = Timer::default();
    let args = Args::parse();
    let ins = Instance::read(&args.input);
    let variant = match args.variant.as_str() {
        "base" => Variant::Base,
        "pair" => Variant::Pair,
        "learn" => Variant::Learn,
        "pair_learn" => Variant::PairLearn,
        v => panic!("unknown variant {v}"),
    };
    let mut model = Tsptw::new(ins.clone(), variant, args.kmax);
    model.use_index = !args.no_index;
    model.cap = args.cap;
    model.plog.path = args.dump_certs.clone();
    model.bound_gate = !args.no_gate;
    model.loc_stats = args.loc_stats;
    model.static_k = args.static_k;
    model.no_learn = args.no_learn;
    model.clear_each_round = args.clear_each_round;
    model.mode = match args.cert_mode.as_str() {
        "lu" => CertMode::Lu,
        "local" => CertMode::Local,
        "dead" => CertMode::Dead,
        "locbound" => CertMode::LocBound,
        "locset" => CertMode::LocSet,
        m => panic!("unknown --cert-mode {m}"),
    };
    let params = SearchParameters { time_limit: Some(args.time_limit), ..Default::default() };
    // The solver owns the model; the model prints its pruning statistics when dropped.
    let mut solver = if args.astar {
        solvers::create_astar(model, params)
    } else {
        solvers::create_cabs(model, params, CabsParameters::default())
    };
    let solution = io::run_solver_and_dump_solution_history(&mut solver, &args.history).unwrap();
    io::print_solution_statistics(&solution);
    let valid = solution.cost.map(|c| ins.validate(&solution.transitions, c));
    println!(
        "RESULT {{\"variant\":\"{}\",\"cost\":{},\"optimal\":{},\"infeasible\":{},\"best_bound\":{},\"expanded\":{},\"generated\":{},\"time\":{:.4},\"valid\":{},\"total_time\":{:.4}}}",
        args.variant,
        solution.cost.map_or("null".into(), |c| c.to_string()),
        solution.is_optimal,
        solution.is_infeasible,
        solution.best_bound.map_or("null".into(), |c| c.to_string()),
        solution.expanded,
        solution.generated,
        solution.time,
        valid.map_or("null".into(), |v| v.to_string()),
        timer.get_elapsed_time()
    );
    drop(solver); // prints STATS from Tsptw::drop
}

impl Drop for Tsptw {
    fn drop(&mut self) {
        self.st.static_used = self.certs.iter().filter(|c| c.fixed && c.used).count() as u64;
        if let Some(p) = &self.plog.path {
            use std::io::Write;
            let mut f = std::fs::File::create(p).expect("cannot write proof log");
            for (u, l, a, t) in &self.plog.certs {
                writeln!(f, "C {:?} {:?} {} {}", u, l, a, t).unwrap();
            }
            for (uid, a, t, r) in &self.plog.events {
                writeln!(f, "E {} {} {} {:?}", uid, a, t, r).unwrap();
            }
            writeln!(f, "N {} {}", self.plog.certs.len(), self.plog.seen_events).unwrap();
        }
        let s = &self.st;
        let line = format!(
            "STATS {{\"variant\":\"{:?}\",\"expanded_calls\":{},\"pruned_single\":{},\"pruned_pair\":{},\"pruned_cert\":{},\"dead_states\":{},\"certs\":{},\"extract_failed\":{},\"evictions\":{},\"skipped_by_bound\":{},\"t_pair\":{:.4},\"t_cert\":{:.4},\"t_extract\":{:.4},\"cert_sizes\":{:?},\"loc_same\":{},\"loc_other\":{},\"loc_other_only\":{},\"dup_learned\":{},\"static_certs\":{},\"static_used\":{},\"t_static\":{:.4}}}",
            self.variant, s.expanded, s.pruned_single, s.pruned_pair, s.pruned_cert, s.dead_states,
            s.certs, s.extract_failed, s.evictions, s.skipped_by_bound, s.t_pair, s.t_cert, s.t_extract, s.cert_size_hist, s.loc_same, s.loc_other, s.loc_other_only, s.dup_learned, s.static_certs, s.static_used, s.t_static
        );
        println!("{line}");
        // sparse trace of where certificates were learned vs where they pruned (depth and round)
        let n = self.ins.a.len();
        let dep: Vec<String> = (0..n * n).filter(|&i| self.tr_depth[i] > 0)
            .map(|i| format!("[{},{},{}]", i / n, i % n, self.tr_depth[i])).collect();
        let rnd: Vec<String> = (0..MAXR * MAXR).filter(|&i| self.tr_round[i] > 0)
            .map(|i| format!("[{},{},{}]", i / MAXR, i % MAXR, self.tr_round[i])).collect();
        println!("TRACE {{\"rounds\":{},\"mode\":\"{:?}\",\"depth\":[{}],\"round\":[{}]}}", self.round, self.mode, dep.join(","), rnd.join(","));
    }
}
